# GovClaim Studio — Railway-first GitHub Starter

**Current phase:** Railway-only foundation. BHEL/ECHS/other schemes are deliberately out of scope until Railway workflow tests pass.

This repository contains the complete current UI source plus a small local Python API and the reviewed bill-reading/print-rule modules. It is a starting codebase for Arena AI to inspect and improve—not a production billing or government-claim approval system.

## Included

- `frontend/index.html` — full UI markup.
- `frontend/assets/css/app.css` — full visual design, including Ice Silver `#DDE3E8`, Deep Aubergine `#3A0F34`, Marigold `#EAAA00`, responsiveness, print styles and reduced-motion behavior.
- `frontend/assets/js/app.js` — current navigation, demo workbench, mapping/consumable examples, preview, review states and prototype interactions.
- `frontend/assets/js/motion.js` — restrained desktop pointer-tilt effects with reduced-motion support.
- `frontend/assets/js/api-integration.js` — connects the extraction button to the local PDF parsing API.
- `backend/app/main.py` — FastAPI local API for health/config, print-margin validation and one-PDF extraction.
- `railway_bill_read_rules.py` — evidence-preserving PDF text parsing and conservative candidate code resolution.
- `bill_format_rules.py` — A4 print layout/margins, INR formatting, amount-in-words and total reconciliation.
- `config/` — versioned reader/print settings.
- `data/cghs_code_registry.json` — code/description/specialty reference snapshot with rate fields removed. It is not an approved, current Railway tariff.
- `tests/` — original reader/format tests plus API integration tests with synthetic PDF data only.
- `ARENA_PROMPT.md` — precise handoff prompt for the next Arena AI session.

## Local run (Windows PowerShell)

Open PowerShell in the extracted repository folder:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python run_local.py
```

Then open `http://127.0.0.1:8000`. Interactive API documentation is at `http://127.0.0.1:8000/api/docs`.

If PowerShell blocks activation, use the venv interpreter directly:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run_local.py
```

## Tests

```powershell
python -m unittest discover -s tests -v
```

Tests create synthetic/de-identified PDFs in memory. No real hospital bills are included or required.

## GitHub first upload

For the step-by-step Windows/Hinglish upload instructions, see `GITHUB_UPLOAD_GUIDE_HINGLISH.md`. Extract the ZIP before adding files to your repository; do not upload this ZIP as the source tree.


Create an **empty private repository first** (recommended while this contains internal business logic). Then run these commands from this folder, replacing the URL with your own repository URL:

```bash
git init
git add .
git status
git commit -m "Initial Railway-first GovClaim Studio codebase"
git branch -M main
git remote add origin YOUR_PRIVATE_REPOSITORY_URL
git push -u origin main
```

Before `git add`, run `git status`. Never add real patient PDFs, extracted bill JSON, passwords, API keys, environment files, or local databases. The `.gitignore` excludes those by default.

## What works now

- UI is served locally by FastAPI rather than opened as a standalone HTML file.
- One selected, text-based PDF can be sent to `/api/claims/parse`; the PDF is held in a temporary file and deleted after parsing.
- The reader returns evidence, minimal field candidates, section rows, code candidates and review warnings.
- Print margin presets/geometry can be inspected and validated via API.
- UI navigation, demonstration mapping examples, duplicate-merge demo, preview and print styles exist as a starting frontend.

## What is not implemented yet

- Scanned-PDF OCR; multi-file bundle orchestration; database, authentication or multi-user authorization; persistent claim drafts/audit log.
- Verified Railway tariff catalogue and valid-from date resolver; real deduction/package-inclusion/admissibility engine; government submission formats/API.
- Production duplicate merge across all source types and a complete real extracted-item editor. The UI still contains clearly labelled demo data for those areas.

## Critical policy boundary

The reader and code registry were adapted from a supplied CGHS-oriented reader. **They do not encode official Railway rules.** Do not calculate Railway admissible amounts or apply 50%/25% deductions until the exact official circular/tariff source, effective dates, scope conditions, formula, ordering/rounding, reviewer approval and regression tests are added. No claim passing guarantee is made.

## Security / privacy boundary

The API has no authentication and is intended for local loopback development only. Do not bind it to `0.0.0.0` or publish it to a public host before authentication, authorization, CSRF/rate-limits, encrypted storage, retention/deletion policy and security review are implemented. Upload parsing returns patient fields/source bill lines to the local browser; only use data you are authorized to process. Do not send patient files to Arena AI or GitHub.

## Source and license notes

This starter is assembled from files provided by the user in the conversation and new integration scaffolding. Review ownership and licensing before publishing publicly; no license is asserted here.


## Arena AI engineering prompt pack

The `arena_prompts/` folder contains a sequenced engineering workflow. Begin with `00_READ_FIRST_AND_RUN_ORDER.md`, then apply the master contract and each numbered phase to the connected repository. Each phase must make code changes, add tests, run checks and provide an evidence report. Do not skip straight to pricing/policy automation without approved official Railway source documents.

