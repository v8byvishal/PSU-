# GovClaim Studio — Railway-First Bill Rules Package

**Version:** 1.0.0

## Is package mein kya hai?

Yeh package tumhari upload ki hui do source ZIPs se sirf relevant cheezein leta hai:

- CGHS Enhancement Bot se **hospital bill read/parsing rules**.
- HFOS v5 se **bill ka print format, A4 margin presets, aur bill workflow ke kaam ke advanced options**.

Yeh ek **review-first reading + formatting toolkit** hai. Yeh complete claim approval engine nahi hai aur official Railway rulebook bhi nahi hai. Ismein Railway tariff rates, approved deductions, package limits, medical admissibility decisions ya auto-submission logic nahi hai.

## Files ka use

- `railway_bill_read_rules.py` — Python bill reader, code matching, subtotal extraction, source evidence aur PDF read helper.
- `bill_format_rules.py` — A4 print margins, printable HTML bill, Indian currency formatting, amount-in-words, total reconciliation.
- `data/cghs_code_registry.json` — source snapshot se 1,998 code + description + speciality records. **Rate values purposely remove kiye hain.**
- `config/bill_read_rules.json` — reading rules aur safety gates ka versioned config.
- `config/bill_format_settings.json` — page size, margins, column widths, header/footer aur advanced options.
- `read_bill.py` — local command-line runner.
- `tests/test_rules.py` — synthetic/de-identified bills par tests.
- `SOURCE_MAP.md` — dono ZIPs se kya liya aur kya exclude kiya, uska map.
- `ARENA_PROMPT.md` — Arena AI ko dene ke liye safe integration prompt.

## Install / run

Python 3.10+ recommended hai.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

PDF extraction ke liye PyMuPDF required hai. Basic text-parsing aur print-format functions standard library use karte hain.

### Hospital PDF read karna

```bash
python read_bill.py "path/to/authorized-hospital-bill.pdf" --output outputs/review.json
```

`outputs/review.json` mein patient identifiers ya line-items ho sakte hain. Isse local, authorized environment mein rakho; GitHub/Arena prompt mein real patient bill ya extraction JSON upload mat karo.

Python se bhi use kar sakte ho:

```python
from railway_bill_read_rules import parse_hospital_bill_pdf

result = parse_hospital_bill_pdf("path/to/authorized-hospital-bill.pdf")
print(result["summary"] if "summary" in result else result["warnings"])
```

Reader evidence/candidates return karta hai. Railway ke allowed payable rates ya deductions decide nahi karta.

## Bill print preview banana

```python
from bill_format_rules import render_printable_bill_html

html = render_printable_bill_html({
    "patient": {
        "bill_number": "DEMO-001",
        "bill_date": "26-Oct-2026",
        "patient_name": "Demo Patient",
        "age_sex": "60 / M",
        "admission_date": "20-Oct-2026",
        "discharge_date": "25-Oct-2026"
    },
    "settings": {
        "bill_title": "Railway Medical Claim",
        "amount_in_words": True
    },
    "rows": [
        {
            "code": "LB042",
            "particular": "Example test — verify code and rate",
            "rate": "0.00",
            "quantity": 1,
            "amount": "0.00"
        }
    ],
    "total": "0.00",
    "credit_line": "Hospital / Credit Details"
})

with open("bill_preview.html", "w", encoding="utf-8") as f:
    f.write(html)
```

Yeh example sirf print layout dikhata hai. Zero rate intentionally diya gaya hai; iska matlab yeh nahi ki test Railway claim mein admissible hai.

## Bill-reading rules ka summary

- PDF ko PyMuPDF text blocks se read kiya jata hai. Blocks ko Y-position ke aas-paas group karke left-to-right order mein rakha jata hai.
- CGHS-style code resolution exact registry match use karta hai. Fuzzy matching, guessed code, code ranges se automatic expansion allowed nahi hai.
- Unknown/ambiguous code `REVIEW_REQUIRED` ya `UNLISTED_REVIEW` mein jaata hai.
- `C002` ko `CC002` tabhi candidate banaya jaata hai jab usi row mein Oxygen context ho. Blood Bank/Packed Cell context mein reject/review hota hai.
- `C004`, `C008`, `C010`, `C011`, `C012`, `C014` jaise aliases ko same-row context wording aur registry match chahiye. `C003` auto-resolve nahi hota.
- `Dept Sub Total` details source position ke saath return hote hain. Service summary, patient-payable aur payer boundaries ko double-counting se bachane ke liye handle kiya gaya hai.
- `DRUG100` (IP Pharmacy + OT Pharmacy subtotal) aur `CNSU100` (consumables subtotals) legacy reading aggregates hain—**Railway mein separately pay karne ka rule nahi**.
- `CC001`, `WC001`, `CN002` ki legacy Room Rent derived quantities sirf review candidates hain; inhe Railway payment rule na samjho.
- Default A4 print margins: top 60 mm, bottom 20 mm, left/right 12 mm. Same top reserve continuation pages par bhi apply hota hai. Short-letterhead aur plain-paper presets bhi hain.
- Legacy CGHS order `CC001 → WC001 → CN002` default se OFF hai; ise Railway rule ki tarah silently apply nahi kiya jayega.

## Production se pehle

1. Railway ke applicable official circulars, effective dates, ward/tier, package inclusions, deductions aur approved rate source verify karna hoga.
2. Versioned Railway rule/tariff data alag se add karna hoga.
3. Unknown/unlisted items ke liye human review required rahe.
4. Approved, de-identified sample bills aur expected output se golden tests add karo.
5. UI/backend production integration se pehle actual browser print preview, totals reconciliation aur error paths test karo.

**Yeh package claim pass hone ki guarantee nahi deta.** Iska kaam bill data ko evidence ke saath read karna aur formal format mein present karne mein help karna hai.
