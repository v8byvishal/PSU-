"""
Railway-first hospital-bill reader rules, derived from supplied project references.

Important scope:
- This module reads bill evidence and proposes code/section candidates.
- It does NOT determine Railway admissibility, rates, package inclusions, or deductions.
- Legacy derived codes are included as reviewable candidates only, not auto-approved claims.
- Unknown or ambiguous values remain review-required; never create a code/rate from a guess.

Runtime dependency:
    pip install pymupdf
Only PDF I/O requires PyMuPDF. Pure text/rule functions use Python's standard library.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable, Mapping, Optional, Sequence
import json
import re

PACKAGE_DIR = Path(__file__).resolve().parent
DEFAULT_REGISTRY_PATH = PACKAGE_DIR / "data" / "cghs_code_registry.json"

RULES_VERSION = "1.0.0"
EXECUTABLE = "EXECUTABLE"
REVIEW_REQUIRED = "REVIEW_REQUIRED"
UNLISTED_REVIEW = "UNLISTED_REVIEW"
REJECTED = "REJECTED"

# These are text-structure rules observed in the supplied source parser.
DEPARTMENT_SERVICE_CODE = "999311"
_DEPT_HEADER_RE = re.compile(
    r"(?m)^[ \t]*(?P<header>[A-Za-z][^\n]{0,160}?\(\s*999311\s*\))[ \t]*$"
)
_SUBTOTAL_LABEL_RE = re.compile(r"Dept\s*Sub\s*Total", re.IGNORECASE)
_SERVICE_SUMMARY_HEADING_RE = re.compile(
    r"(?:Official\s*)?Service\s*(?:Wise\s*)?Summary", re.IGNORECASE
)
_AMOUNT_RE = re.compile(r"(?<![A-Za-z])(?:₹\s*)?(-?\d[\d,]*\.\d{2})(?!\d)")
_WHOLE_AMOUNT_LINE_RE = re.compile(r"^[ \t]*(?:₹\s*)?(-?\d[\d,]*\.\d{2})[ \t]*$")
_PAYER_REGION_CLOSE_RE = re.compile(r"Payer\s+Payable\s+Total\s*:", re.IGNORECASE)
_PATIENT_PAYABLE_TOTAL_RE = re.compile(r"Patient\s+Payable\s+Total\s*:", re.IGNORECASE)
_PATIENT_PAYABLE_RE = re.compile(r"Patient\s*Payable", re.IGNORECASE)
_YEAR_SUFFIX_RE = re.compile(r"-\s*20\s*\d\s*\d\b|-\s*20\d{2}\b", re.IGNORECASE)

LOCKED_CATEGORY_COMPOSITION = {
    ("L", "B"): "LB",
    ("G", "P"): "GP",
    ("P", "T"): "PT",
    ("C", "N"): "CN",
    ("R", "P"): "RP",
    ("M", "G"): "MG",
    ("A", "G"): "AG",
    ("E", "P"): "EP",
    ("N", "S"): "NS",
    ("N", "U"): "NU",
    ("B", "C"): "BC",
}
LOCKED_NUMERIC_CATEGORIES = frozenset(
    {"LB", "RI", "CI", "RP", "GP", "PT", "CN", "CC", "WC", "MG"}
)
CONTEXT_ALIAS_RULES = {
    "C004": ( "CC004", re.compile(r"NIV\s*MACHINE", re.I), "NIV Machine Per Day" ),
    "C008": ( "CC008", re.compile(r"BLOOD\s*TRANSFUSION", re.I), "Blood Transfusion Charge" ),
    "C010": ( "CC010", re.compile(r"ENDO\s*TRACHEAL", re.I), "Endotracheal Intubation" ),
    "C011": ( "CC011", re.compile(r"CENTRAL\s*LINE", re.I), "Central Line" ),
    "C012": ( "CC012", re.compile(r"NEBULI[SZ]", re.I), "Nebulizer Therapy" ),
    "C014": ( "CC014", re.compile(r"RYLE'?S?\s*TUBE", re.I), "Ryles Tube Insertion Charge" ),
}
NEVER_RESOLVED_ALIASES = frozenset({"C003"})
OXYGEN_CONTEXT_RE = re.compile(r"OXYGEN", re.I)
BLOOD_BANK_CONTEXT_RE = re.compile(r"BLOOD\s*BANK|PACKED\s*CELL", re.I)
RAW_ALIAS_RE = re.compile(r"^C\d{3}$")
EXPLICIT_CODE_RE = re.compile(r"^[A-Z]{1,3}\d{3}$")
CODE_PARTS_RE = re.compile(r"([A-Z]{0,2}\d{3}(?:\s*\+\s*[A-Z]*\d{3})*)", re.I)

# Field allow-list: don't bulk-copy every personal detail on the original invoice.
CLAIM_FIELD_ALLOWLIST = (
    "patient_name", "age_sex", "hospital_patient_id", "ip_number", "bill_number",
    "bill_date", "admission_date", "discharge_date", "payer_or_scheme",
    "authorization_reference", "ward_or_room_category", "doctor_or_speciality",
)
DEFAULT_EXCLUDED_PATIENT_FIELDS = (
    "full_address", "phone_number", "guardian_name", "employer_pan", "GSTIN",
    "attendant_name", "unrelated_reference_ids",
)


@dataclass(frozen=True)
class RuleOccurrence:
    final_code: Optional[str]
    status: str
    reason: str
    original_token: str
    raw_expression: str
    category: str
    page: Optional[int]
    section: str
    service_name: str
    source_row_text: str
    locked_quantity: Optional[Decimal] = None

    def to_dict(self) -> dict[str, Any]:
        out = asdict(self)
        out["locked_quantity"] = (
            str(self.locked_quantity) if self.locked_quantity is not None else None
        )
        return out


def normalize_text(value: Any) -> str:
    """Normalize invisible spacing while preserving the meaningful source text."""
    if value is None:
        return ""
    return (
        str(value)
        .replace("\u00a0", " ")
        .replace("\u200b", " ")
        .replace("\ufeff", "")
        .replace("\u2010", "-")
        .replace("\u2011", "-")
        .replace("\u2012", "-")
        .replace("\u2013", "-")
        .replace("\u2014", "-")
        .replace("\r\n", "\n")
        .replace("\r", "\n")
    )


def parse_money(value: Any) -> Optional[Decimal]:
    """
    Parse a money value using Indian comma grouping and decimal point.
    Returns None (not zero) when the text is not a defensible numeric amount.
    """
    if value is None:
        return None
    raw = normalize_text(value).strip()
    if not raw or "%" in raw:
        return None

    negative = bool(re.search(r"^\s*-|\(\s*.*\s*\)|-\s*$", raw))
    cleaned = re.sub(r"(?i)\b(?:INR|RS\.?|RUPEES?)\b", "", raw)
    cleaned = cleaned.replace("₹", "").replace(",", "")
    cleaned = re.sub(r"[^\d.\-]", "", cleaned)
    if cleaned in ("", "-", ".", "-."):
        return None
    # Reject multiple decimal points rather than silently repairing malformed input.
    if cleaned.count(".") > 1:
        return None
    try:
        amount = Decimal(cleaned)
    except InvalidOperation:
        return None
    if negative and amount > 0:
        amount = -amount
    return amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def parse_quantity_token(value: Any) -> Optional[Decimal]:
    """Parse an explicit quantity without integer-truncating fractional units."""
    if value is None:
        return None
    raw = normalize_text(value).strip().replace(",", "")
    if not re.fullmatch(r"\d+(?:\.\d{1,3})?", raw):
        return None
    try:
        qty = Decimal(raw)
    except InvalidOperation:
        return None
    return qty if qty > 0 else None


@lru_cache(maxsize=4)
def load_code_registry(path: str = str(DEFAULT_REGISTRY_PATH)) -> dict[str, dict[str, Any]]:
    """
    Load only code identity fields. Rates are intentionally absent from this registry.
    The caller must provide a separately verified tariff master for any rate lookup.
    """
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    records = payload.get("records", [])
    registry = {}
    for row in records:
        code = normalize_text(row.get("code", "")).strip().upper()
        if not code or code in registry:
            raise ValueError(f"Invalid or duplicate registry code: {code!r}")
        registry[code] = row
    return registry


def _alias_region(row_text: str, marker_end: int) -> str:
    """Limit code search to the area after a CGHS marker and before the first amount."""
    region = normalize_text(row_text)[marker_end:marker_end + 120]
    money = _AMOUNT_RE.search(region)
    if money:
        region = region[:money.start()]
    region = _YEAR_SUFFIX_RE.sub("", region)
    region = re.sub(r"\b([A-Z])-(\d{3})\b", r"\1\2", region, flags=re.I)
    # PDF text sometimes fragments digits, e.g. "B042+0 43".
    for _ in range(2):
        region = re.sub(r"(?<=\d)\s+(?=\d)", "", region)
    return region


def _resolve_code_component(
    category: str,
    token: str,
    prefix: str,
    number: str,
    row_upper: str,
    valid_codes: set[str],
) -> tuple[Optional[str], str, str, Optional[Decimal]]:
    """Resolve a single code token. Inference requires exact registry membership."""
    composed_family = LOCKED_CATEGORY_COMPOSITION.get((category, prefix))
    is_explicit_composed_alias = bool(
        composed_family and f"{composed_family}{number}" in valid_codes
    )

    if RAW_ALIAS_RE.fullmatch(token) and not is_explicit_composed_alias:
        if token in NEVER_RESOLVED_ALIASES:
            return None, REVIEW_REQUIRED, (
                f"UNRESOLVED_MAPPING: {token} has no approved target; code invention is forbidden"
            ), None

        if token == "C002":
            if BLOOD_BANK_CONTEXT_RE.search(row_upper):
                return None, REVIEW_REQUIRED, (
                    "UNRESOLVED_MAPPING: C002 appears in Blood Bank/Packed Cell context, not Oxygen"
                ), None
            if OXYGEN_CONTEXT_RE.search(row_upper):
                qty, qty_reason = parse_oxygen_quantity_with_reason(row_upper)
                if qty_reason == "contradictory_full_half":
                    return None, REVIEW_REQUIRED, (
                        "UNRESOLVED_MAPPING: same row contains conflicting FULL DAY and HALF DAY evidence"
                    ), None
                if "CC002" in valid_codes:
                    return "CC002", EXECUTABLE, (
                        f"C002 + Oxygen evidence in same row => CC002; {qty_reason}"
                    ), Decimal(qty)
                return None, REVIEW_REQUIRED, (
                    "UNRESOLVED_MAPPING: CC002 target is not in the approved code registry"
                ), None
            return None, REVIEW_REQUIRED, (
                "UNRESOLVED_MAPPING: C002 needs OXYGEN evidence in the same row"
            ), None

        locked = CONTEXT_ALIAS_RULES.get(token)
        if locked:
            final, evidence, description = locked
            if not evidence.search(row_upper):
                return None, REVIEW_REQUIRED, (
                    f"UNRESOLVED_MAPPING: {token} requires same-row '{description}' evidence"
                ), None
            if final not in valid_codes:
                return None, REVIEW_REQUIRED, (
                    f"UNRESOLVED_MAPPING: target {final} is absent from the code registry"
                ), None
            return final, EXECUTABLE, (
                f"{token} + same-row '{description}' evidence => {final}"
            ), None

        return None, REVIEW_REQUIRED, (
            f"UNRESOLVED_MAPPING: no locked context rule resolves raw alias {token}"
        ), None

    if EXPLICIT_CODE_RE.fullmatch(token):
        if token in valid_codes:
            return token, EXECUTABLE, f"Exact code token {token} exists in code registry", None
        return None, REVIEW_REQUIRED, (
            f"UNRESOLVED_MAPPING: explicit code {token} is absent from the code registry"
        ), None

    if composed_family:
        candidate = f"{composed_family}{number}"
        if candidate in valid_codes:
            return candidate, EXECUTABLE, (
                f"Locked composition CGHS-{category} + {token} => {candidate}"
            ), None
        return None, REVIEW_REQUIRED, (
            f"UNRESOLVED_MAPPING: candidate {candidate} is absent from the code registry"
        ), None

    if not prefix and category in LOCKED_NUMERIC_CATEGORIES:
        candidate = f"{category}{number}"
        if candidate in valid_codes:
            return candidate, EXECUTABLE, (
                f"Locked numeric composition CGHS-{category} + {number} => {candidate}"
            ), None
        return None, REVIEW_REQUIRED, (
            f"UNRESOLVED_MAPPING: candidate {candidate} is absent from the code registry"
        ), None

    return None, REVIEW_REQUIRED, (
        f"UNRESOLVED_MAPPING: category {category!r} with token {token!r} has no approved composition"
    ), None


def parse_oxygen_quantity_with_reason(row_text: str) -> tuple[int, str]:
    """Legacy parser rule: Oxygen FULL DAY=24, HALF DAY=12, otherwise 1."""
    upper = normalize_text(row_text).upper()
    full = bool(re.search(r"FULL\s*DAY|FULLDAY|24\s*HRS|24\s*HOURS", upper))
    half = bool(re.search(r"HALF\s*DAY|HALFDAY|12\s*HRS|12\s*HOURS", upper))
    if full and half:
        return 1, "contradictory_full_half"
    if full:
        return 24, "explicit full-day oxygen wording"
    if half:
        return 12, "explicit half-day oxygen wording"
    return 1, "oxygen wording present; no duration, quantity defaulted to 1 and should be reviewed"


def parse_oxygen_quantity(row_text: str) -> int:
    return parse_oxygen_quantity_with_reason(row_text)[0]


def resolve_cghs_code_occurrences(
    row_text: str,
    *,
    page: Optional[int] = None,
    section: str = "",
    service_name: str = "",
    valid_codes: Optional[Iterable[str]] = None,
) -> list[dict[str, Any]]:
    """
    Row-aware CGHS code resolver. Every occurrence carries original evidence.
    Unknown/ambiguous tokens are never dropped and are never converted into rates.
    """
    source = normalize_text(row_text).strip()
    if not source:
        return []
    upper = source.upper()
    if valid_codes is None:
        code_set = set(load_code_registry())
    else:
        code_set = {normalize_text(x).strip().upper() for x in valid_codes if x}

    occurrences: list[RuleOccurrence] = []
    if "CGHS" not in upper:
        return []

    for marker in re.finditer(r"CGHS[-\s]*([A-Z]{1,3})", upper):
        category = (marker.group(1) or "").strip()
        region = _alias_region(source, marker.end())
        expression = CODE_PARTS_RE.search(region)
        if not expression:
            continue

        normalized_expr = re.sub(r"\s*\+\s*", "+", expression.group(1)).upper()
        parts = [part for part in normalized_expr.split("+") if part]
        raw_expression = normalized_expr
        if parts and not re.match(r"^[A-Z]", parts[0]):
            raw_expression = f"{category}{normalized_expr}"

        for index, part in enumerate(parts):
            shape = re.fullmatch(r"([A-Z]{0,2})(\d{3})", part)
            if not shape:
                continue
            prefix, number = shape.group(1), shape.group(2)
            final = None
            status = REVIEW_REQUIRED
            reason = "UNRESOLVED_MAPPING: code token could not be resolved"
            locked_qty = None

            # Only carry a code family when the first token explicitly proves it
            # and every intermediate component is a numeric-only three-digit token.
            carried = None
            if not prefix and index > 0:
                first = re.fullmatch(r"([A-Z]{1,2})(\d{3})", parts[0])
                middle_ok = all(re.fullmatch(r"\d{3}", p) for p in parts[1:index])
                if first and middle_ok:
                    family = LOCKED_CATEGORY_COMPOSITION.get((category, first.group(1)))
                    possible = f"{family}{number}" if family else None
                    if possible and possible in code_set:
                        carried = possible

            if not prefix and len(parts) > 1 and index > 0:
                if carried:
                    final, status, reason = carried, EXECUTABLE, (
                        f"Prefix carried from explicit first component of {raw_expression} => {carried}; exact registry match"
                    )
                else:
                    final, status, reason = None, REVIEW_REQUIRED, (
                        f"UNRESOLVED_MAPPING: component {part} of compound {raw_expression} has no proven prefix"
                    )
            else:
                final, status, reason, locked_qty = _resolve_code_component(
                    category, part, prefix, number, upper, code_set
                )

            occurrences.append(RuleOccurrence(
                final_code=final,
                status=status,
                reason=reason,
                original_token=part,
                raw_expression=raw_expression,
                category=category,
                page=page,
                section=section,
                service_name=service_name,
                source_row_text=source[:500],
                locked_quantity=locked_qty,
            ))

    return [item.to_dict() for item in occurrences]


def parse_row_quantity_with_evidence(row_text: str) -> dict[str, Any]:
    """
    Read quantity from a quantity / 3-7 digit reference / amount triplet.
    Unlike the legacy implementation this returns Decimal and does not truncate
    fractional quantities. A fallback of 1 is explicitly marked as an assumption.
    """
    source = normalize_text(row_text)
    matches = list(re.finditer(
        r"(?<!\d)(\d+(?:\.\d{1,3})?)\s+(\d{3,7})\s+([\d,]+\.\d{2})(?!\d)",
        source
    ))
    candidates = []
    for m in matches:
        qty = parse_quantity_token(m.group(1))
        if qty is not None and qty <= Decimal("1000"):
            candidates.append((m, qty))
    if candidates:
        m, qty = candidates[-1]
        return {
            "quantity": str(qty),
            "status": "EXPLICIT_PATTERN",
            "evidence": m.group(0),
            "reason": "Quantity/reference/amount triplet recognized; source row retained",
        }
    return {
        "quantity": "1",
        "status": REVIEW_REQUIRED,
        "evidence": "",
        "reason": "No unambiguous quantity pattern; 1 is a display fallback only and must be confirmed",
    }


def _department_sections(text: str) -> tuple[list[dict[str, Any]], Optional[int]]:
    """Index anchored department headers and the payer-to-patient payable boundary."""
    source = normalize_text(text)
    headers = [
        (m.start(), m.end(), m.group("header").strip())
        for m in _DEPT_HEADER_RE.finditer(source)
    ]
    sections: list[dict[str, Any]] = []
    for index, (start, header_end, header) in enumerate(headers):
        next_start = headers[index + 1][0] if index + 1 < len(headers) else len(source)
        section_text = source[start:next_start]
        # `header_end` is an absolute offset in the full source; convert it to
        # a section-local offset before searching the sliced section text.
        has_subtotal = bool(_SUBTOTAL_LABEL_RE.search(section_text, header_end - start))
        sections.append({
            "start": start,
            "header_end": header_end,
            "header": header,
            "end": next_start,
            "is_detailed": has_subtotal,
        })
    payer_close = _PAYER_REGION_CLOSE_RE.search(source)
    return sections, (payer_close.end() if payer_close else None)


def _service_summary_span(text: str, sections: list[dict[str, Any]]) -> Optional[tuple[int, int]]:
    first_detail = next((s for s in sections if s["is_detailed"]), None)
    if first_detail is None:
        return None
    heading = _SERVICE_SUMMARY_HEADING_RE.search(text, 0, first_detail["start"])
    return (heading.start() if heading else 0, first_detail["start"])


def _amount_for_subtotal_label(section_text: str, label_match: re.Match) -> Optional[Decimal]:
    # Preferred layout: value after "Dept Sub Total" on the same line.
    line_end = section_text.find("\n", label_match.end())
    if line_end < 0:
        line_end = len(section_text)
    remainder = section_text[label_match.end():line_end]
    after = _AMOUNT_RE.search(remainder)
    if after:
        return parse_money(after.group(1))

    # Alternate layout: a whole amount line immediately before the label.
    line_start = section_text.rfind("\n", 0, label_match.start()) + 1
    before_line = section_text[max(0, section_text.rfind("\n", 0, line_start - 1) + 1):line_start].strip()
    before_match = _WHOLE_AMOUNT_LINE_RE.fullmatch(before_line)
    if before_match:
        return parse_money(before_match.group(1))

    # Alternate layout: amount on the line immediately after the label.
    if line_end < len(section_text):
        next_start = line_end + 1
        next_end = section_text.find("\n", next_start)
        if next_end < 0:
            next_end = len(section_text)
        next_match = _WHOLE_AMOUNT_LINE_RE.fullmatch(section_text[next_start:next_end])
        if next_match:
            return parse_money(next_match.group(1))
    return None


def collect_department_subtotals(text: str, department_pattern: str) -> list[dict[str, Any]]:
    """
    Collect all detailed 'Dept Sub Total' amounts for one department.
    Summary rows are excluded, same-position labels are de-duplicated, equal amounts
    at different positions are preserved, and Patient Payable sections are excluded
    but remain in the returned provenance.
    """
    source = normalize_text(text)
    if not isinstance(department_pattern, str) or not department_pattern:
        raise ValueError("department_pattern must be a non-empty regular expression")
    wanted = re.compile(department_pattern, re.IGNORECASE)
    sections, patient_region_start = _department_sections(source)
    summary_span = _service_summary_span(source, sections)
    found: list[dict[str, Any]] = []
    seen_positions: set[int] = set()

    for section in sections:
        if not wanted.search(section["header"]):
            continue
        start, end = section["start"], section["end"]
        if summary_span and summary_span[0] <= start < summary_span[1]:
            continue
        if not section["is_detailed"]:
            continue

        slice_text = source[start:end]
        header_text = section["header"]
        if _PATIENT_PAYABLE_RE.search(header_text):
            exclusion_reason = "department header identifies Patient Payable"
        elif _PATIENT_PAYABLE_TOTAL_RE.search(slice_text):
            exclusion_reason = "section closes with Patient Payable Total"
        elif patient_region_start is not None and start >= patient_region_start:
            exclusion_reason = "section begins after Payer Payable Total boundary"
        else:
            exclusion_reason = ""

        for match in _SUBTOTAL_LABEL_RE.finditer(slice_text):
            absolute_pos = start + match.start()
            if absolute_pos in seen_positions:
                continue
            seen_positions.add(absolute_pos)
            amount = _amount_for_subtotal_label(slice_text, match)
            if amount is None or amount <= 0:
                found.append({
                    "amount": None,
                    "included": False,
                    "position": absolute_pos,
                    "department": header_text,
                    "reason": "subtotal label found but no positive, readable amount was attached",
                })
                continue
            found.append({
                "amount": str(amount),
                "included": not bool(exclusion_reason),
                "position": absolute_pos,
                "department": header_text,
                "reason": exclusion_reason or "included detailed department subtotal",
            })

    return sorted(found, key=lambda item: item["position"])


def _sum_included(entries: Sequence[Mapping[str, Any]]) -> Decimal:
    total = Decimal("0.00")
    for entry in entries:
        if entry.get("included") and entry.get("amount") is not None:
            total += Decimal(str(entry["amount"]))
    return total.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def reconcile_pharmacy(text: str) -> dict[str, Any]:
    """Legacy reading rule only: detailed IP Pharmacy + OT Pharmacy subtotals."""
    ip_entries = collect_department_subtotals(text, r"IP\s*Pharmacy")
    ot_entries = collect_department_subtotals(text, r"OT\s*Pharmacy")
    ip_total = _sum_included(ip_entries)
    ot_total = _sum_included(ot_entries)
    all_entries = [
        {"label": "IP Pharmacy", **entry} for entry in ip_entries
    ] + [
        {"label": "OT Pharmacy", **entry} for entry in ot_entries
    ]
    return {
        "ip_detailed": str(ip_total),
        "ot_detailed": str(ot_total),
        "total": str((ip_total + ot_total).quantize(Decimal("0.01"))),
        "provenance": all_entries,
        "summary_values_used_in_total": False,
        "warning": "Legacy CGHS source-parser aggregate only; not a Railway admissibility rule.",
    }


def extract_consumables_total(text: str) -> dict[str, Any]:
    """Legacy reading rule: all detailed Consumables department subtotals, excluding Patient Payable."""
    entries = collect_department_subtotals(text, r"Consumable")
    included = [
        {"department": e["department"], "amount": e["amount"], "position": e["position"]}
        for e in entries if e.get("included") and e.get("amount") is not None
    ]
    return {
        "total": str(_sum_included(entries)),
        "included_sections": included,
        "provenance": entries,
        "warning": "Legacy CGHS source-parser aggregate only; do not auto-add to a Railway package without rule verification.",
    }


def cluster_pdf_blocks_into_rows(blocks: Sequence[Sequence[Any]], y_tolerance: float = 12.0) -> list[dict[str, Any]]:
    """Cluster PyMuPDF blocks into visual rows by y-proximity, ordered left to right."""
    valid = [b for b in blocks if len(b) >= 5 and normalize_text(b[4]).strip()]
    valid.sort(key=lambda b: (float(b[1]), float(b[0])))
    clusters: list[list[Sequence[Any]]] = []
    current: list[Sequence[Any]] = []
    current_y: Optional[float] = None
    for block in valid:
        x0, y0, _x1, _y1, block_text = block[:5]
        if current_y is None or abs(float(y0) - current_y) < y_tolerance:
            current.append(block)
            if current_y is None:
                current_y = float(y0)
        else:
            clusters.append(current)
            current = [block]
            current_y = float(y0)
    if current:
        clusters.append(current)

    result = []
    for group in clusters:
        ordered = sorted(group, key=lambda b: float(b[0]))
        row_text = " ".join(normalize_text(b[4]).replace("\n", " ").strip() for b in ordered)
        result.append({
            "y0": min(float(b[1]) for b in group),
            "row_text": re.sub(r"\s+", " ", row_text).strip(),
            "blocks": len(group),
        })
    return result


def extract_service_rows_from_pages(pages_blocks: Sequence[Sequence[Sequence[Any]]]) -> list[dict[str, Any]]:
    """
    Source-format row extraction: track department headers and capture rows that
    contain a CGHS marker outside the Room Rent section. Keep page/section/raw text.
    """
    service_rows: list[dict[str, Any]] = []
    current_section = ""
    for page_index, blocks in enumerate(pages_blocks, start=1):
        for cluster in cluster_pdf_blocks_into_rows(blocks):
            combined = cluster["row_text"]
            if not combined:
                continue
            header_match = _DEPT_HEADER_RE.fullmatch(combined)
            if header_match and len(combined) < 180:
                current_section = header_match.group("header").strip()
                continue
            upper = combined.upper()
            if "ROOM RENT(999311" in upper or "ROOM RENT (999311" in upper:
                current_section = "ROOM RENT(999311)"
                continue
            if "CGHS" in upper:
                if "ROOM RENT" in current_section.upper():
                    continue
                service_name = re.split(r"CGHS", combined, maxsplit=1, flags=re.I)[0].strip()[:200]
                service_rows.append({
                    "page": page_index,
                    "section": current_section,
                    "service_name": service_name,
                    "row_text": combined[:1000],
                    "evidence": "CGHS marker present in this extracted row",
                })
    return service_rows


def extract_room_rent_rows(pages_blocks: Sequence[Sequence[Sequence[Any]]]) -> dict[str, Any]:
    """
    Legacy derivation evidence: count only Room Rent item rows within the Room Rent
    department; it never reads a money amount as a quantity.
    """
    rows: list[dict[str, Any]] = []
    current_section = ""
    for page_index, blocks in enumerate(pages_blocks, start=1):
        for cluster in cluster_pdf_blocks_into_rows(blocks):
            text = cluster["row_text"]
            upper = text.upper()
            head = _DEPT_HEADER_RE.fullmatch(text)
            if head:
                current_section = head.group("header").strip().upper()
                continue
            if "ROOM RENT(999311" in upper or "ROOM RENT (999311" in upper:
                current_section = "ROOM RENT(999311)"
                continue
            if "ROOM RENT" not in current_section or "ROOM RENT(" not in upper:
                continue
            if "ICU" in upper:
                row_type = "ICU"
            elif any(k in upper for k in ("AC MULTIBEDS", "AC MULTIBED", "MULTIBEDS", "SINGLE")):
                row_type = "WARD"
            else:
                row_type = "WARD_OTHER"
            qty_info = parse_row_quantity_with_evidence(text)
            rows.append({
                "page": page_index,
                "row_type": row_type,
                "row_text": text[:500],
                "quantity_evidence": qty_info,
            })
    icu_count = sum(1 for r in rows if r["row_type"] == "ICU")
    ward_count = sum(1 for r in rows if r["row_type"] != "ICU")
    return {
        "rows": rows,
        "icu_row_count": icu_count,
        "ward_row_count": ward_count,
        "legacy_CC001_candidate_qty": icu_count,
        "legacy_WC001_candidate_qty": ward_count,
        "legacy_CN002_candidate_qty": icu_count * 3 + ward_count * 2,
        "status": REVIEW_REQUIRED,
        "warning": "Legacy-derived candidates only. WC001 may be absent from the master code list; these are not Railway payment rules.",
    }


def _extract_header_candidates(full_text: str) -> dict[str, Any]:
    """
    Conservatively surface only minimal claim fields. Exact layout extraction varies
    by hospital; this helper returns candidates with evidence rather than asserting
    ambiguous multi-column labels are correct.
    """
    lines = normalize_text(full_text).splitlines()
    patterns = {
        "patient_name": [r"^\s*(?:Patient\s+)?Name\s*:\s*(.+?)\s*$"],
        "hospital_patient_id": [r"^\s*(?:UHID|Hospital\s+ID)\s*:?\s*(.*)$"],
        "ip_number": [r"^\s*IP\s*(?:Number|No\.?)\s*:?\s*(.*)$"],
        "bill_number": [r"^\s*Bill\s*(?:No\.?|Number)\s*:?\s*(.*)$"],
        "age_sex": [r"^\s*(?:Age\s*/\s*Sex|Age|Sex)\s*:?\s*(.+?)\s*$"],
        "admission_date": [r"^\s*Admission\s+Date\s*:?\s*(.*)$"],
        "discharge_date": [r"^\s*Discharge\s+Date\s*:?\s*(.*)$"],
        "payer_or_scheme": [r"^\s*(?:TPA/Corporate|Bill\s+To|Payer)\s*:?\s*(.*)$"],
        "authorization_reference": [r"^\s*Authorization\s+No\.?\s*:?\s*(.*)$"],
        "ward_or_room_category": [r"^\s*(?:Ward\s+Name|Bed\s+No\.?|Room\s+Category)\s*:?\s*(.*)$"],
        "doctor_or_speciality": [r"^\s*(?:Doctor\s+Name|Speciality)\s*:?\s*(.*)$"],
        "bill_date": [r"^\s*Bill\s+Date\s*:?\s*(.*)$"],
    }
    out: dict[str, Any] = {}
    label_at_line = re.compile(
        r"^\s*(?:Name|Patient\s+Name|UHID|Hospital\s+ID|IP\s*(?:Number|No\.?)|"
        r"Bill\s*(?:No\.?|Number|Date)|Age\s*/\s*Sex|Age|Sex|Admission\s+Date|"
        r"Discharge\s+Date|TPA/Corporate|Bill\s+To|Payer|Authorization\s+No\.?|"
        r"Ward\s+Name|Bed\s+No\.?|Room\s+Category|Doctor\s+Name|Speciality)\b",
        re.I,
    )
    for field, regexes in patterns.items():
        candidate = None
        evidence = None
        confidence = "LOW"
        for idx, line in enumerate(lines):
            for pattern in regexes:
                match = re.match(pattern, line, re.I)
                if not match:
                    continue
                value = normalize_text(match.group(1)).strip(" :\t*")
                if value and not label_at_line.match(value):
                    candidate, evidence, confidence = value, line.strip(), "MEDIUM"
                    break
                # If a label is blank or broken over lines, only accept the next
                # line if it looks like a value and not another label.
                for next_idx in range(idx + 1, min(idx + 4, len(lines))):
                    nxt = lines[next_idx].strip().strip(":").strip()
                    if not nxt:
                        continue
                    if label_at_line.match(nxt):
                        break
                    if re.fullmatch(r"[*\w./-]{2,80}", nxt):
                        candidate, evidence, confidence = nxt.strip("* "), f"{line.strip()} -> {nxt}", "LOW"
                        break
                    break
                if candidate:
                    break
            if candidate:
                break
        out[field] = {
            "value": candidate,
            "confidence": confidence if candidate else "NOT_FOUND",
            "source_evidence": evidence,
            "needs_confirmation": bool(candidate and confidence != "HIGH"),
        }
    return out


def parse_hospital_bill_pdf(pdf_path: str | Path, registry_path: str | Path = DEFAULT_REGISTRY_PATH) -> dict[str, Any]:
    """
    Read PDF text/geometry and return extraction candidates + evidence.
    The result is review-oriented; it does not price, deduct, or submit a claim.
    """
    try:
        import fitz  # PyMuPDF loaded lazily
    except ImportError as exc:
        raise RuntimeError(
            "PDF reading requires PyMuPDF. Install it with: pip install pymupdf"
        ) from exc

    file_path = Path(pdf_path)
    if not file_path.is_file():
        raise FileNotFoundError(file_path)
    registry = load_code_registry(str(Path(registry_path).resolve()))
    code_set = set(registry)

    pages_blocks: list[Sequence[Sequence[Any]]] = []
    page_texts: list[str] = []
    with fitz.open(file_path) as document:
        for page in document:
            pages_blocks.append(page.get_text("blocks"))
            page_texts.append(page.get_text("text"))
    full_text = "\n".join(page_texts)

    service_rows = extract_service_rows_from_pages(pages_blocks)
    code_candidates: list[dict[str, Any]] = []
    for row in service_rows:
        occurrences = resolve_cghs_code_occurrences(
            row["row_text"],
            page=row["page"],
            section=row["section"],
            service_name=row["service_name"],
            valid_codes=code_set,
        )
        if not occurrences:
            code_candidates.append({
                "source_page": row["page"],
                "source_section": row["section"],
                "source_row_text": row["row_text"],
                "final_code": None,
                "status": UNLISTED_REVIEW,
                "reason": "CGHS marker found but no code-like expression was resolved",
            })
        else:
            code_candidates.extend(occurrences)

    pharmacy = reconcile_pharmacy(full_text)
    consumables = extract_consumables_total(full_text)
    room_rent = extract_room_rent_rows(pages_blocks)
    header_candidates = _extract_header_candidates(full_text)

    review_count = sum(
        1 for item in code_candidates
        if item.get("status") != EXECUTABLE
    )
    warnings = []
    if not service_rows:
        warnings.append("No CGHS-marked item rows were found; verify PDF quality/layout and manually review unlisted items.")
    if review_count:
        warnings.append(f"{review_count} code occurrence(s) need review; no fuzzy code/rate was assigned.")
    warnings.append("No tariff, Railway deduction, package inclusion or admissible amount was calculated.")
    return {
        "schema_version": RULES_VERSION,
        "source_file_name": file_path.name,
        "pages_read": len(page_texts),
        "reader": "PyMuPDF text blocks + section-aware extraction rules",
        "patient_fields_minimal": header_candidates,
        "service_rows": service_rows,
        "code_candidates": code_candidates,
        "unlisted_review": [
            item for item in code_candidates if item.get("status") == UNLISTED_REVIEW
            or item.get("status") == REVIEW_REQUIRED
        ],
        "legacy_pharmacy_reading": pharmacy,
        "legacy_consumables_reading": consumables,
        "legacy_room_rent_candidates": room_rent,
        "review_count": review_count,
        "claim_status": "REVIEW_REQUIRED",
        "warnings": warnings,
    }


def explain_rule_scope() -> dict[str, Any]:
    """Machine-readable guard that consuming applications can inspect before use."""
    return {
        "rules_version": RULES_VERSION,
        "active_purpose": "bill reading and evidence-preserving extraction only",
        "railway_policy_implemented": False,
        "rates_embedded": False,
        "automatic_deductions_implemented": False,
        "unknown_code_action": UNLISTED_REVIEW,
        "unknown_rate_action": REVIEW_REQUIRED,
        "final_submission_allowed_by_this_module": False,
    }


__all__ = [
    "CLAIM_FIELD_ALLOWLIST",
    "DEFAULT_EXCLUDED_PATIENT_FIELDS",
    "EXECUTABLE",
    "REVIEW_REQUIRED",
    "UNLISTED_REVIEW",
    "LOCKED_CATEGORY_COMPOSITION",
    "LOCKED_NUMERIC_CATEGORIES",
    "RuleOccurrence",
    "cluster_pdf_blocks_into_rows",
    "collect_department_subtotals",
    "explain_rule_scope",
    "extract_consumables_total",
    "extract_room_rent_rows",
    "extract_service_rows_from_pages",
    "load_code_registry",
    "normalize_text",
    "parse_hospital_bill_pdf",
    "parse_money",
    "parse_oxygen_quantity",
    "parse_oxygen_quantity_with_reason",
    "parse_row_quantity_with_evidence",
    "reconcile_pharmacy",
    "resolve_cghs_code_occurrences",
]
