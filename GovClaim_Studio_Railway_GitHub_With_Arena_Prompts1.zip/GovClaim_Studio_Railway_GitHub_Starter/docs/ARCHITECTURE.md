# Architecture (Railway Phase 1)

```text
Browser
  └── FastAPI static frontend: frontend/index.html + assets
        ├── GET /api/health and /api/config
        ├── POST /api/claims/parse (one PDF, temporary local file, delete after parse)
        └── GET/POST /api/print/margins (presets and geometry validation)

PDF text blocks ──> railway_bill_read_rules.py ──> evidence + candidates + warnings
Bill preview rules ──> bill_format_rules.py ──> A4 print HTML / totals checks
JSON config ──> parser/format settings; code-only registry ──> exact identity lookup
```

No database, auth, OCR, external AI request, official rate lookup, Railway deduction logic or claim submission exists yet. API is local-development only.
