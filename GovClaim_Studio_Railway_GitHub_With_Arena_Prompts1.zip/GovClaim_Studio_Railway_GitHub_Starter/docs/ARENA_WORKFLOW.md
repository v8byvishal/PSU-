# Arena AI workflow — phased implementation

1. Start at `arena_prompts/00_READ_FIRST_AND_RUN_ORDER.md`.
2. Paste `arena_prompts/01_MASTER_ENGINEERING_CONTRACT.md` as the persistent engineering contract.
3. Run each numbered prompt from `02_BASELINE_AUDIT_AND_STABILIZATION.md` through `14_RELEASE_GATE_AND_HANDOVER.md` against the same repository, one phase at a time.
4. For each phase, inspect current Git status, run baseline tests, implement the scoped change, add tests, run final tests, review diff, commit and report exact evidence. Do not proceed if acceptance fails.
5. `15_OPTIONAL_SCANNED_PDF_OCR.md` is optional and only after the text-PDF pipeline passes.
6. `16_FUTURE_SCHEME_PLUGIN_BOUNDARY.md` is future-only; do not activate BHEL/ECHS until Railway has passed its release gate and the owner provides/approves the required official sources.

The prompt pack makes no assumption that the existing CGHS-derived code list is an approved Railway tariff. Rates, effective dates, package inclusion and deductions stay disabled until sourced to official documents and test fixtures.

Do not send identifiable patient bills to Arena or commit them to GitHub. Use generated synthetic PDFs only for tests.
