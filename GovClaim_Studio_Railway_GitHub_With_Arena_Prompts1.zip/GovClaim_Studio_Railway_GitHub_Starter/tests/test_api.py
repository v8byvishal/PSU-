import io
import sys
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from backend.app.main import app


class LocalApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)

    def test_health_is_clear_about_policy_limits(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertTrue(body["pdf_text_extraction"])
        self.assertFalse(body["official_rates_connected"])
        self.assertFalse(body["railway_policy_engine_connected"])

    def test_root_serves_full_ui(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("GovClaim Studio", response.text)
        self.assertIn("/assets/css/app.css", response.text)

    def test_print_margin_endpoint(self):
        response = self.client.get("/api/print/margins")
        self.assertEqual(response.status_code, 200)
        self.assertIn("standard_letterhead", response.json()["presets"])
        invalid = self.client.post("/api/print/margins/validate", json={"margins_mm":{"top":200,"bottom":100,"left":12,"right":12}})
        self.assertEqual(invalid.status_code, 200)
        self.assertFalse(invalid.json()["valid"])

    def test_rejects_non_pdf_upload(self):
        response = self.client.post("/api/claims/parse", files={"file": ("note.txt", b"hello", "text/plain")})
        self.assertEqual(response.status_code, 415)

    def test_rejects_malformed_pdf_with_pdf_signature(self):
        response = self.client.post(
            "/api/claims/parse",
            files={"file": ("broken.pdf", b"%PDF-1.7\nnot really a PDF", "application/pdf")},
        )
        self.assertEqual(response.status_code, 422)
        self.assertIn("PDF extraction failed", response.json()["detail"])

    def test_parses_synthetic_pdf_without_enabling_adjudication(self):
        try:
            import fitz
        except ImportError:
            self.skipTest("PyMuPDF missing")
        doc = fitz.open()
        page = doc.new_page()
        page.insert_text((40, 50), "Name: DEMO PATIENT")
        page.insert_text((40, 75), "IP Number: DEMO-IP-1")
        page.insert_text((40, 100), "Bill No: DEMO-BILL-1")
        page.insert_text((40, 150), "Investigations(999311 )")
        page.insert_text((40, 175), "1 Demo Test CGHS-LB042 1.00 100.00")
        pdf_bytes = doc.tobytes()
        doc.close()
        response = self.client.post(
            "/api/claims/parse",
            files={"file": ("synthetic_demo.pdf", io.BytesIO(pdf_bytes), "application/pdf")},
        )
        self.assertEqual(response.status_code, 200, response.text)
        body = response.json()
        self.assertEqual(body["pages_read"], 1)
        self.assertFalse(body.get("rates_embedded", False))
        self.assertEqual(body["claim_status"], "REVIEW_REQUIRED")
        self.assertIn("No tariff", " ".join(body["warnings"]))
        self.assertNotIn("synthetic_demo.pdf", str(body.get("patient_fields_minimal", {})))


if __name__ == "__main__":
    unittest.main(verbosity=2)
