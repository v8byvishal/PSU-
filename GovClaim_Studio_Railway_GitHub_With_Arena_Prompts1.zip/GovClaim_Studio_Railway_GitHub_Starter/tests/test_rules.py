import json
import sys
import unittest
from decimal import Decimal
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import railway_bill_read_rules as reader
import bill_format_rules as formatter


class RulePackageTests(unittest.TestCase):
    def test_registry_has_exact_source_snapshot_and_no_rates(self):
        registry = reader.load_code_registry()
        self.assertEqual(len(registry), 1998)
        self.assertIn("LB042", registry)
        self.assertEqual(registry["LB042"]["description"], "Hepatitis B Surface Antigen (HBsAg)")
        raw = json.loads((ROOT / "data" / "cghs_code_registry.json").read_text(encoding="utf-8"))
        self.assertFalse(raw["rates_included"])
        self.assertTrue(all("rate" not in k.lower() for r in raw["records"] for k in r))

    def test_money_parser_handles_indian_commas_and_negative(self):
        self.assertEqual(reader.parse_money("₹1,20,000.50"), Decimal("120000.50"))
        self.assertEqual(reader.parse_money("(1,200.00)"), Decimal("-1200.00"))
        self.assertEqual(reader.parse_money("not-a-number"), None)

    def test_exact_code_and_same_row_alias_rules(self):
        exact = reader.resolve_cghs_code_occurrences("Serum marker CGHS-LB042 1.00 250.00", page=2)
        self.assertEqual(exact[0]["final_code"], "LB042")
        self.assertEqual(exact[0]["status"], reader.EXECUTABLE)

        oxygen = reader.resolve_cghs_code_occurrences("OXYGEN FULL DAY CGHS-C C002 1.00 250.00", page=3)
        self.assertEqual(oxygen[0]["final_code"], "CC002")
        self.assertEqual(oxygen[0]["locked_quantity"], "24")

        blood_bank = reader.resolve_cghs_code_occurrences("BLOOD BANK PACKED CELL CGHS-C C002 1.00 250.00")
        self.assertIsNone(blood_bank[0]["final_code"])
        self.assertEqual(blood_bank[0]["status"], reader.REVIEW_REQUIRED)

    def test_ambiguous_aliases_never_invent_a_code(self):
        unresolved = reader.resolve_cghs_code_occurrences("Treatment CGHS-C C003 1.00 500.00")
        self.assertIsNone(unresolved[0]["final_code"])
        self.assertEqual(unresolved[0]["status"], reader.REVIEW_REQUIRED)

        no_context = reader.resolve_cghs_code_occurrences("Equipment CGHS-C C004 1.00 500.00")
        self.assertIsNone(no_context[0]["final_code"])
        self.assertEqual(no_context[0]["status"], reader.REVIEW_REQUIRED)

        unknown = reader.resolve_cghs_code_occurrences("Unknown procedure CGHS-ZZ999 1.00 500.00")
        self.assertIsNone(unknown[0]["final_code"])
        self.assertEqual(unknown[0]["status"], reader.REVIEW_REQUIRED)

    def test_oxygen_contradictory_duration_is_review_required(self):
        occurrences = reader.resolve_cghs_code_occurrences(
            "OXYGEN FULL DAY HALF DAY CGHS-C C002 1.00 250.00"
        )
        self.assertIsNone(occurrences[0]["final_code"])
        self.assertIn("conflicting", occurrences[0]["reason"].lower())

    def test_department_subtotals_exclude_payer_patient_payable_and_summary(self):
        bill_text = """Service Summary
IP Pharmacy(999311 )
Summary display amount 125.00
OT Pharmacy(999311 )
Summary display amount 25.00
IP Pharmacy(999311 )
Medicine A 1.00 100.00
Dept Sub Total : 100.00
OT Pharmacy(999311 )
Medicine B 1.00 20.00
Dept Sub Total : 20.00
OT Consumables(999311 )
Item C 2.00 40.00
Dept Sub Total : 40.00
Payer Payable Total: 160.00
IP Pharmacy(999311 )
Patient payable display
Dept Sub Total : 999.00
Patient Payable Total: 999.00
"""
        pharmacy = reader.reconcile_pharmacy(bill_text)
        self.assertEqual(pharmacy["ip_detailed"], "100.00")
        self.assertEqual(pharmacy["ot_detailed"], "20.00")
        self.assertEqual(pharmacy["total"], "120.00")
        excluded = [p for p in pharmacy["provenance"] if p["amount"] == "999.00"]
        self.assertTrue(excluded)
        self.assertFalse(excluded[0]["included"])

        consumables = reader.extract_consumables_total(bill_text)
        self.assertEqual(consumables["total"], "40.00")

    def test_subtotal_amount_before_label_is_supported(self):
        bill_text = "IP Pharmacy(999311 )\nItem A\n100.00\nDept Sub Total\n"
        results = reader.collect_department_subtotals(bill_text, r"IP\s*Pharmacy")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["amount"], "100.00")

    def test_pdf_block_clustering_is_left_to_right(self):
        blocks = [
            (200, 10, 250, 20, "100.00", 0, 0),
            (20, 10, 90, 20, "CGHS-LB042", 0, 0),
            (100, 10, 180, 20, "Creatinine", 0, 0),
            (20, 30, 100, 40, "Next row", 0, 0),
        ]
        rows = reader.cluster_pdf_blocks_into_rows(blocks)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["row_text"], "CGHS-LB042 Creatinine 100.00")
        self.assertEqual(rows[1]["row_text"], "Next row")

    def test_margin_presets_and_geometry(self):
        default = formatter.validate_margins()
        self.assertTrue(default["valid"])
        self.assertEqual(default["margins_mm"]["top"], "60")
        self.assertEqual(default["geometry"]["usable_width_mm"], "186")
        self.assertEqual(default["geometry"]["usable_height_mm"], "217")
        self.assertTrue(default["geometry"]["same_top_reserve_on_continuation_pages"])

        short = formatter.margin_preset("short_letterhead")
        self.assertEqual(short, {"top": 45, "bottom": 18, "left": 12, "right": 12})
        self.assertFalse(formatter.validate_margins({"top": -1})["valid"])
        self.assertFalse(formatter.validate_margins({"top": 200, "bottom": 100})["valid"])

    def test_rupees_words_and_totals_reconciliation(self):
        self.assertEqual(formatter.format_rupees("1234567.895"), "12,34,567.90")
        self.assertEqual(formatter.format_rupees("-1200"), "-1,200.00")
        self.assertEqual(
            formatter.amount_in_words_inr(421250),
            "Four Lakh Twenty One Thousand Two Hundred Fifty Rupees Only",
        )
        valid = formatter.validate_bill_totals([{"amount": "12.50"}, {"amount": "7.50"}], "20.00")
        self.assertTrue(valid["valid"])
        invalid = formatter.validate_bill_totals([{"amount": "12.50"}, {"amount": "7.50"}], "21.00")
        self.assertFalse(invalid["valid"])
        self.assertEqual(invalid["status"], "REVIEW_REQUIRED")

    def test_legacy_display_priority_is_disabled_by_default(self):
        rows = [{"code": "C000"}, {"code": "CN002"}, {"code": "CC001"}, {"code": "WC001"}]
        default_order = formatter.apply_row_order(rows)
        self.assertEqual(default_order, rows)
        legacy_order = formatter.apply_row_order(rows, enable_legacy_cghs_priority=True)
        self.assertEqual([r["code"] for r in legacy_order[:3]], ["CC001", "WC001", "CN002"])

    def test_printable_html_is_monochrome_and_escapes_input(self):
        html = formatter.render_printable_bill_html({
            "patient": {
                "bill_number": "DEMO-001",
                "bill_date": "26-Oct-2026",
                "patient_name": "<script>alert(1)</script>",
                "age_sex": "60 / M",
                "admission_date": "20-Oct-2026",
                "discharge_date": "25-Oct-2026",
            },
            "settings": {"bill_title": "Railway Medical Claim"},
            "rows": [{"code": "LB042", "particular": "Example", "rate": "0", "quantity": 1, "amount": "0"}],
            "total": "0",
        })
        self.assertIn("@page { size: A4 portrait; margin: 60mm 12mm 20mm 12mm;", html)
        self.assertIn("display: table-header-group", html)
        self.assertIn("&lt;script&gt;", html)
        self.assertNotIn("<script>alert(1)</script>", html)
        self.assertIn("CGHS CODE", html)
        self.assertIn("width:45.5%", html)
        self.assertIn("width:15.5%", html)

    def test_source_scope_disclaimer_and_field_allowlist_are_present(self):
        rules = json.loads((ROOT / "config" / "bill_read_rules.json").read_text(encoding="utf-8"))
        self.assertTrue(rules.get("not_a_policy"))
        self.assertIn("patient_data_minimization", rules)
        self.assertIn("claim_safety_gates", rules)
        self.assertIn("rates", (ROOT / "README_HINGLISH.md").read_text(encoding="utf-8").lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
