(() => {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  if (reduceMotion || !finePointer) return;
  document.querySelectorAll('.metric, .catalog-card, .rule-card').forEach(card => {
    card.classList.add('tilt-ready');
    card.addEventListener('pointermove', event => {
      if (event.pointerType !== 'mouse') return;
      const rect = card.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const x = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
      const y = Math.min(1, Math.max(0, (event.clientY - rect.top) / rect.height));
      card.style.setProperty('--tilt-x', `${((0.5 - y) * 3.1).toFixed(2)}deg`);
      card.style.setProperty('--tilt-y', `${((x - 0.5) * 3.8).toFixed(2)}deg`);
      card.style.setProperty('--spot-x', `${(x * 100).toFixed(1)}%`);
      card.style.setProperty('--spot-y', `${(y * 100).toFixed(1)}%`);
    }, {passive: true});
    card.addEventListener('pointerleave', () => {
      ['--tilt-x','--tilt-y','--spot-x','--spot-y'].forEach(property => card.style.removeProperty(property));
    }, {passive: true});
  });
})();
