/* Local API integration: only the first selected PDF is parsed in Phase 1. */
(() => {
  const statusNode = document.getElementById('apiStatus');
  const button = document.getElementById('runExtractBtn');
  if (!button) return;

  // Replace the existing demo-only click handler so it cannot claim real extraction ran.
  const liveButton = button.cloneNode(true);
  button.replaceWith(liveButton);

  const htmlEscape = (value) => String(value ?? '').replace(/[&<>"']/g, ch => ({
    '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
  }[ch]));

  async function checkHealth() {
    if (!statusNode) return;
    try {
      const response = await fetch('/api/health', { cache: 'no-store' });
      if (!response.ok) throw new Error('API not ready');
      const payload = await response.json();
      statusNode.innerHTML = '<span class="live-dot"></span> RAILWAY WORKSPACE · LOCAL API ONLINE';
      statusNode.title = `Backend ${htmlEscape(payload.version || 'unknown')}`;
    } catch (_) {
      statusNode.innerHTML = '<span class="live-dot"></span> RAILWAY WORKSPACE · UI ONLY';
      statusNode.title = 'Start the local server with: python run_local.py';
    }
  }

  function renderResult(result, originalName) {
    const patient = result.patient_fields_minimal || {};
    const fieldRows = Object.entries(patient).map(([key, detail]) => {
      const value = detail && typeof detail === 'object' ? detail.value : detail;
      const confidence = detail && typeof detail === 'object' ? detail.confidence : '';
      const evidence = detail && typeof detail === 'object' ? detail.source_evidence : '';
      return `<tr><td>${htmlEscape(key.replaceAll('_',' '))}</td><td>${htmlEscape(value || 'Not found')}</td><td>${htmlEscape(confidence || '')}</td><td>${htmlEscape(evidence || '')}</td></tr>`;
    }).join('');
    const candidates = (result.code_candidates || []).slice(0, 30).map(item => `<tr>
      <td>${htmlEscape(item.source_page ?? '')}</td>
      <td>${htmlEscape(item.source_section || '')}</td>
      <td>${htmlEscape(item.source_row_text || '')}</td>
      <td>${htmlEscape(item.final_code || 'UNLISTED')}</td>
      <td>${htmlEscape(item.status || 'REVIEW_REQUIRED')}</td>
      <td>${htmlEscape(item.reason || '')}</td>
    </tr>`).join('');
    const warnings = (result.warnings || []).map(item => `<li>${htmlEscape(item)}</li>`).join('');
    const body = `
      <p><strong>Actual PDF text extraction finished.</strong> This is a review result, not an approved claim or pricing result.</p>
      <div class="summary-strip">
        <div class="sum-card"><span>Source file</span><strong>${htmlEscape(originalName)}</strong></div>
        <div class="sum-card"><span>Pages read</span><strong>${htmlEscape(result.pages_read)}</strong></div>
        <div class="sum-card"><span>Rows / review items</span><strong>${htmlEscape((result.service_rows||[]).length)} / ${htmlEscape(result.review_count ?? 0)}</strong></div>
      </div>
      <div class="notice" style="margin-top:12px"><strong>Important:</strong> no Railway rates, admissibility decision, package deductions or payable totals were calculated.</div>
      <h3>Minimal claim fields (confirm every value)</h3>
      <div class="table-wrap"><table class="data-table"><thead><tr><th>Field</th><th>Extracted value</th><th>Confidence</th><th>Source evidence</th></tr></thead><tbody>${fieldRows || '<tr><td colspan="4">No fields extracted.</td></tr>'}</tbody></table></div>
      <h3 style="margin-top:18px">Code candidates and source rows (first 30)</h3>
      <div class="table-wrap"><table class="data-table"><thead><tr><th>Page</th><th>Section</th><th>Original row</th><th>Code</th><th>Status</th><th>Reason</th></tr></thead><tbody>${candidates || '<tr><td colspan="6">No code candidates found; inspect pages manually.</td></tr>'}</tbody></table></div>
      <h3 style="margin-top:18px">Warnings</h3><ul>${warnings || '<li>No additional warnings returned.</li>'}</ul>
      <p class="tiny-note">Source evidence remains tied to the PDF page/row. Unmatched items must be reviewed. This API does not use external AI or store uploaded PDF files permanently.</p>
      <button class="btn btn-primary" id="downloadActualExtraction">Download extraction review JSON</button>`;
    window.govClaimApp.showModal('Bill extraction review', body);
    document.getElementById('downloadActualExtraction')?.addEventListener('click', () => {
      window.govClaimApp.downloadText('bill-extraction-review.json', JSON.stringify(result, null, 2), 'application/json');
    });
  }

  liveButton.addEventListener('click', async () => {
    const app = window.govClaimApp;
    const files = app?.state?.files || [];
    const pdf = files.find(file => file && (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')));
    if (!pdf) {
      app?.toast('Pehle actual hospital bill PDF choose karo. Placeholder demo rows parse nahi hoti.');
      return;
    }
    const oldText = liveButton.textContent;
    liveButton.disabled = true;
    liveButton.textContent = 'Reading PDF…';
    try {
      const form = new FormData();
      form.append('file', pdf, pdf.name);
      const response = await fetch('/api/claims/parse', { method: 'POST', body: form, cache: 'no-store' });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.detail || `Extraction failed (HTTP ${response.status})`);
      document.getElementById('extractState').textContent = 'Actual PDF parsed';
      document.getElementById('metricExtraction').textContent = `${(payload.patient_fields_minimal ? Object.values(payload.patient_fields_minimal).filter(x => x && x.value).length : 0)}/12`;
      document.getElementById('metricReview').textContent = String(payload.review_count ?? 0).padStart(2,'0');
      window.__govClaimLastExtraction = payload;
      renderResult(payload, pdf.name);
      app?.toast('PDF text extraction complete. Please review the source evidence and unresolved items.');
    } catch (error) {
      app?.toast(`PDF extraction error: ${error.message}`);
      window.govClaimApp.showModal('PDF extraction failed', `<p>${htmlEscape(error.message)}</p><p>Check that the local server is running and the file is a readable text-based PDF. Scanned-image OCR is not yet connected.</p>`);
    } finally {
      liveButton.disabled = false;
      liveButton.textContent = oldText;
      checkHealth();
    }
  });

  checkHealth();
})();
