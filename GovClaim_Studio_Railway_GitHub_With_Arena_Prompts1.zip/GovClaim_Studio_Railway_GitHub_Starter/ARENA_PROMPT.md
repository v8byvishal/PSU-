# Arena AI — GovClaim Studio execution entry point

This repository contains a phased engineering prompt pack in `arena_prompts/`. Follow it in order; do not attempt a giant rewrite in one generation.

## Start here
1. Read `arena_prompts/00_READ_FIRST_AND_RUN_ORDER.md`.
2. Paste the full content of `arena_prompts/01_MASTER_ENGINEERING_CONTRACT.md` into Arena as the persistent engineering contract.
3. Then run `arena_prompts/02_BASELINE_AUDIT_AND_STABILIZATION.md`.
4. Complete prompts 03 through 14 one by one, only proceeding after the prior phase's acceptance checks pass.
5. `15_OPTIONAL_SCANNED_PDF_OCR.md` is optional and only after text extraction is stable. `16_FUTURE_SCHEME_PLUGIN_BOUNDARY.md` must not run until Railway workflow is accepted and BHEL/other official source documents are reviewed.

## Non-negotiable
- Railway only in current scope.
- Never invent a tariff, effective date, rate, deduction, package inclusion or Railway rule.
- The current CGHS-derived registry is identity/reference metadata, not an approved Railway rate master.
- Do not place real patient bills or extracted patient data in GitHub or Arena.
- Preserve source evidence and human review; calculations are deterministic and Decimal-based.
- Make actual source changes, add tests, run them, inspect the diff and report precise evidence. Never claim an unrun test passed.

See `README.md` and `docs/ARCHITECTURE.md` for the current codebase. These prompts are instructions to upgrade the existing repository, not a replacement application.
