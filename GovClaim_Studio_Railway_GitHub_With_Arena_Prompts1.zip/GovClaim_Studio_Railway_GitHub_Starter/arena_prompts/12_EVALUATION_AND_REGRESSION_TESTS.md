# PHASE 11 — Evidence-based evaluation, golden fixtures and regression suite

Apply the Master Engineering Contract and the evaluation-first principles of AI Engineering: make measurable claims, keep a frozen test set, evaluate failures by class, and never use a plausible-looking result as proof of correctness.

## Objective
Create a reliable local test harness for bill reading, source matching, merging, reconciliation, validation and rendering. Avoid external model calls and real patient records.

## Synthetic fixture set
Build deterministic PDF documents in memory or from generated test code (never commit patient source documents), covering:
- summary + detail pages where the same total appears twice;
- multiple section headings, split pages and repeated headers/footers;
- wrapped line descriptions, item codes and amounts in separate columns;
- code missing, code unknown, two code candidates, false-positive code patterns;
- pharmacy/consumables categories and compatible/incompatible duplicate items;
- malformed, encrypted, oversized, empty/scanned-style and rotated PDF pages;
- Indian comma formatting, zero, negative adjustments, refunds/deposits/discounts;
- malicious HTML/JS text, oversized strings and weird Unicode;
- date boundary and catalogue version differences;
- missing policy evidence, draft/expired/revoked rules, and conflicting policy conditions.

## Evaluation harness
- Separate exact extraction expectations from tolerant layout-derived expectations.
- Report field extraction precision/recall where a gold truth exists; row detection precision/recall; exact code token resolution; false positive count; unlisted recall; currency amount absolute error; totals reconciliation error; and unsafe auto-match/auto-merge count (target: zero).
- Store gold expected outputs with no personal/medical real-world data; use stable IDs and decimal strings.
- For deterministic components, use golden snapshots with intentional review/approval for snapshot updates.
- For fuzzy suggestions, measure candidate recall but keep all results human-reviewed; no fuzzy score can itself mean admissible.
- Every prior bug fix gets a regression test with a meaningful name.

## Test layers
1. Unit tests for parser/normalization/Decimal/rules/merging/print config.
2. API contract/integration tests for upload, validation, temporary cleanup, draft state and export gates.
3. Frontend tests for state transitions, escaping and disabled controls; browser smoke test if browser tooling is available.
4. Clean environment install and Windows instructions validation where feasible.
5. Security-focused tests from Phase 10.

## CI
Update GitHub Actions to run unit/API tests on supported Python version(s), `git diff --check` equivalent if practical, and optionally lint/type checks only if dependencies are pinned and used consistently. CI must never need patient documents or secrets. Keep failures visible; don't silently skip required suites.

## Acceptance thresholds
- All deterministic unit/API tests pass.
- Unsafe automatic rate selection, unsafe auto-deduction and unsafe auto-merge must equal zero in fixture set.
- Unknown/ambiguous items must stay unlisted/review-required.
- Totals must reconcile exactly within configured Decimal tolerance or be blocking.
- Every automatic rule result has source/rule version lineage; no source evidence means no automatic policy result.
- Report coverage/metrics only when computed by a runnable command from actual fixtures. Do not invent a numeric “accuracy” claim.

## Deliverables
- `tests/fixtures/` contains generated/synthetic materials only; protect `.gitignore` from raw bill uploads.
- Add `scripts/run_quality_gate.py` or equivalent if useful.
- Add `docs/EVALUATION.md` with metrics, how to run, limitations and last run date.
- Commit `test: add synthetic bill evaluation and regression gates`.
