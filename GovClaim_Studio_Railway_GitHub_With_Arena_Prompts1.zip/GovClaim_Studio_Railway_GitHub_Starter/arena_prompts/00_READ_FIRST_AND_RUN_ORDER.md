# Arena AI Prompt Pack — Read First

## Purpose

This folder is the execution plan for the existing **GovClaim Studio Railway-first repository**. It is not a request to generate a new project from scratch. Run prompts one at a time, in numerical order, against the same Git repository. Every prompt asks Arena to inspect, implement, test and report—not just give advice.

## Before starting

1. Push the starter repository to a private GitHub repository.
2. Connect that repository to Arena AI.
3. Make sure the branch is clean and the latest commit is visible to Arena.
4. Give Arena `01_MASTER_ENGINEERING_CONTRACT.md` first. Then give `02_BASELINE_AUDIT_AND_STABILIZATION.md`.
5. For each later phase, paste exactly one phase prompt and wait for its completion report before sending the next prompt.
6. Have Arena commit each phase separately. Review its diff and test results before continuing.
7. Never upload real patient bills, extracted patient JSON, credentials, or production databases to GitHub or to Arena unless the hospital has explicitly authorized the processing channel.

## Prompt order

| Order | Prompt | Goal |
|---:|---|---|
| 0 | `01_MASTER_ENGINEERING_CONTRACT.md` | Rules every Arena run must follow |
| 1 | `02_BASELINE_AUDIT_AND_STABILIZATION.md` | Audit repository, establish test baseline, fix only justified defects |
| 2 | `03_UI_FUNCTIONAL_WORKBENCH.md` | Turn UI controls into honest, usable interactions connected to real API state |
| 3 | `04_PDF_INGESTION_AND_EXTRACTION.md` | Harden one-PDF text extraction and preserve evidence |
| 4 | `05_DOMAIN_MODEL_EDITING_AND_DRAFTS.md` | Create canonical claim/item models and human-edit/review workflows |
| 5 | `06_CODE_CATALOGUE_MATCHING.md` | Versioned source catalogue and explainable candidate matching |
| 6 | `07_PHARMACY_CONSUMABLES_SAFE_MERGE.md` | Safe duplicate review, reversible merge and section totals |
| 7 | `08_RAILWAY_POLICY_AND_RATE_ENGINE.md` | Evidence-gated, deterministic Railway rule/rate engine; stays disabled until approved sources exist |
| 8 | `09_VALIDATION_REVIEW_AND_AUDIT.md` | Validation rules, review workflow and change history |
| 9 | `10_PRINT_RENDER_AND_EXPORT.md` | Print-ready claim documents and margin/layout verification |
| 10 | `11_SECURITY_PRIVACY_AND_LOCAL_BOUNDARIES.md` | Local privacy, input safety, no PHI leaks, deployment restrictions |
| 11 | `12_EVALUATION_AND_REGRESSION_TESTS.md` | Gold fixtures, deterministic testing and evaluation reports |
| 12 | `13_WINDOWS_DEVELOPER_EXPERIENCE.md` | Reliable setup/run/test instructions for Windows |
| 13 | `14_RELEASE_GATE_AND_HANDOVER.md` | Final readiness report and release gates |
| Optional | `15_OPTIONAL_SCANNED_PDF_OCR.md` | Local OCR only after text-PDF path passes and dependencies/accuracy/privacy are reviewed |
| Future only | `16_FUTURE_SCHEME_PLUGIN_BOUNDARY.md` | Architecture boundary for BHEL/ECHS; do not activate during Railway phase |

## How to run a prompt

- Paste the full text of the next prompt, not just its title.
- Keep the current branch/repository attached to Arena.
- If Arena hits an environment limitation, it must state that precisely, implement what can be verified, and provide exact commands for anything that must be run locally. It must not invent passing results.
- If required official Railway documents are missing, Arena should implement the disabled policy-engine interface and document the missing inputs—not guess the policy.
- If a prompt fails, fix that phase before moving on. Do not stack later phases on an unstable branch.

## Required end-of-phase report

Arena must report:

1. Baseline result and final test commands with exact pass/fail/skip counts.
2. Files added/changed/deleted and the reason for each meaningful change.
3. API/UI/data contract changes and migration implications.
4. Security/privacy implications, especially patient data.
5. What is genuinely functional versus demo, mocked or blocked.
6. Evidence of validation: test output, API response, screenshot or trace when available.
7. Known gaps and the next smallest safe phase.
8. Commit SHA. If Arena cannot commit, say why and provide the exact commit-ready status.

## Product boundary

Phase 1 is **Indian Railways hospital claim preparation**, with applicable CGHS references only when a verified Railway instruction specifically invokes them for the case. Do not turn the existing CGHS-derived code registry into an assumed Railway tariff. Do not promise government approval. BHEL/ECHS/other payers are future adapters only; they are not active workflows during this sequence.
