# PHASE 2 — Turn the premium UI into an honest, accessible workbench

Apply the Master Engineering Contract. Preserve the existing palette, visual identity and overall layout; improve it without a wholesale rewrite.

## Objective
Make the existing `frontend/index.html`, `frontend/assets/css/app.css`, `frontend/assets/js/app.js`, `motion.js` and `api-integration.js` behave like a real application shell. The backend is still review-only during this phase.

## Required UI behavior
1. Wire API health/config on startup with clear states: `Connecting`, `API online`, `API offline`, `Error`. Avoid presenting “online” when only the page loaded.
2. Add a clear PDF intake area with drag/drop, browse, selected filename, file size, remove/replace, supported type and size explanation, and a visible processing/loading/failed/success state. The backend remains authoritative for validation.
3. On extraction click, call the real `/api/claims/parse` endpoint exactly once for the selected file. Prevent duplicate requests and stale overlapping responses. The actual parsed output must be visually distinguishable from seeded demo data.
4. Render returned fields, source-page evidence, service rows, code candidates and warnings from API data. Use `textContent`/DOM creation where possible; if templating is retained, escape every value including filenames and error messages. Never trust a PDF string as HTML.
5. Provide usable tabs/nav for Overview, Intake/Extraction, Code Review, Pharmacy & Consumables, Rules/Validation, Print Preview and Settings. A tab with no implementation must be visibly disabled with a reason or marked `DEMO`—no fake success.
6. Provide empty/loading/error/retry states. Add keyboard focus, accessible labels, live region for async status, `aria-expanded` for toggles, semantic dialog close/escape behavior, and focus restoration.
7. Preserve colours `#DDE3E8`, `#3A0F34`, `#EAAA00`, the gentle 3D/micro-animation system and reduced-motion support. Avoid excessive movement, low contrast and animation of critical values.
8. Add responsive handling for narrow windows; wide data tables scroll in their own container and keep headings readable.
9. Remove or explicitly label hard-coded example data and counts. Synthetic/demo examples must never be confused with extracted real claim data.
10. Add “Clear session” to remove selected file and in-memory extracted data from the UI; explain this does not erase a browser-downloaded file or any later saved draft.

## Engineering tasks
- Create a simple frontend state model (for example `idle`, `file-selected`, `parsing`, `parsed-review`, `error`) to prevent impossible UI combinations.
- Avoid duplicating event handlers on repeated render. Avoid global namespace pollution beyond the existing documented `window.govClaimApp` API.
- Keep API endpoint paths centralized and response schema documented.
- Show `RULES NOT CONNECTED` wherever policy/rates are referenced; do not display a computed “admissible” figure.
- If a browser automation library is already available, add smoke tests for the main journey. If not, don't claim UI automation ran; add manual verification steps and test the DOM/contracts that are feasible in current tooling.

## Acceptance criteria
- API offline state is visible and actionable.
- Selecting a non-PDF shows validation error; selecting a synthetic text PDF and pressing Extract produces real parser output with page evidence.
- Repeated clicks cannot produce duplicate parsing actions.
- An unknown row remains visible in review queue.
- Every visible button is functional, disabled with a reason, or marked `DEMO`.
- XSS test strings in filenames/fields render as text, not HTML.
- Keyboard-only navigation and reduced motion work; all existing tests pass plus new tests.

## Deliverables
Actual code, tests, updated README/screenshots only if genuinely captured, and commit `feat: connect Railway workbench UI to real extraction state`.
