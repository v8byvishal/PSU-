# FUTURE ONLY — Add BHEL/ECHS/other payers without damaging Railway

**Do not run during the Railway MVP.** Run only after Phase 13 acceptance and a separately reviewed change request.

## Objective
Introduce a modular payer adapter boundary without copying Railway-specific assumptions into other scheme workflows.

## Required architecture
- Payer profile is an adapter/configuration object with scope, applicable catalogues, policy source registry, document checklist, output templates, validators and capability flags.
- Shared core: source document ingestion, evidence lineage, normalized item rows, Decimal arithmetic, review/audit, print renderer abstractions and testing harness.
- Scheme adapters own: tariff source selection, valid dates, eligibility dimensions, package/deduction rules, output format, required documents and submission workflow.
- No scheme inherits another scheme's rate, deduction or scope unless a specific, currently valid official source explicitly says it applies.
- Scheme cannot be selectable until its official source package is imported, versioned, reviewed/approved and it has a scheme-specific gold test suite.
- UI must visibly show active payer/pathway and source version; switching payer invalidates incompatible mappings/calculations and prompts the user to re-review.

## BHEL special caution
The existing `BHEL RET LIST.xlsx` must be ingested as an unverified source snapshot first. Map every original sheet/column, record checksum and effective date if evidenced, and require human validation. Do not assume a filename, sheet title or CGHS-recognised hospital reference establishes BHEL approval. For a missing investigation code, a CGHS candidate is review-only until an official BHEL instruction authorizes that mapping and scope.

## Tests
Cross-scheme leakage; scope mismatch; source date mismatch; mapping invalidation on payer switch; two adapters with contradictory rules; no rates inherited by default; versioned output format; scheme cannot activate with no source package.

## Acceptance
Railway regression suite stays unchanged and passes. The UI does not expose a payer as operational before its evidence gates are met. Commit only after the separate scheme requirements and source documents are approved by the owner.
