# OPTIONAL PHASE — Scanned PDF OCR (do not run before Phase 3 passes)

Apply the Master Engineering Contract. This phase is optional and only begins after the text-based PDF extraction workflow and test suite are stable. Do not send patient PDFs to a third-party OCR or AI service.

## First decision
Inspect what is available in the target Windows environment. Compare local OCR options for install size, language support (English plus any required Hindi), offline processing, maintenance, license, quality, and memory/runtime. Present a short decision record. Add no OCR engine unless dependency, licence and packaging are understood. If the environment lacks an OCR binary/model, OCR remains disabled and documented; do not fake it.

## Pipeline
- Detect pages with empty/low text; only offer OCR for those pages, not blindly the entire PDF.
- Keep original PDF ephemeral. Render pages with pixel/dimension limits; clean rendered images immediately after use.
- Return OCR text with page, bounding boxes, OCR engine/version, language, confidence if engine actually provides it and a `method=OCR` flag.
- Distinguish native text, OCR text and reviewer-entered values. OCR confidence is not policy certainty.
- Never auto-fill policy-sensitive or monetary fields as “verified” from OCR alone. Route low-confidence values to review.
- Add user-configurable page limits and explicit warnings about degraded accuracy.

## Evaluation
Use synthetic PDFs with known text, low-resolution scans, rotated pages, noise, multiple columns, amounts with commas/decimals, codes, names and dates. Measure character/word error rate and especially monetary/code exact match. Keep a held-out synthetic evaluation set. No claim of OCR accuracy without computed metrics.

## Acceptance
- A scanned-only PDF is no longer mislabeled as successfully text-extracted; OCR state is explicit.
- Original page evidence is linked to OCR result.
- Zero automatic pricing/deduction or approval from OCR alone.
- Temporary page images are cleaned after success and failure.
- README, installer and health endpoint accurately reflect OCR status.
Commit `feat: add optional offline OCR with review-first extraction` only after evidence supports it.
