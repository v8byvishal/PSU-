# PHASE 9 — Government-claim print layout, annexures and controlled export

Apply the Master Engineering Contract. Follow the existing HFOS-inspired monochrome A4 layout and its configurable letterhead reserve, but do not copy unrelated HFOS features or patient data.

## Required format defaults
- Paper: A4 portrait by default; allow an approved alternative only via a versioned format profile.
- Margin presets in millimetres (top/bottom/left/right): `standard_letterhead = 60/20/12/12`, `short_letterhead = 45/18/12/12`, `plain_paper = 15/15/12/12`.
- Same top reserve across each page. Validate positive dimensions and usable printable area before rendering.
- Monochrome print. Screen UI colours and animation are not printed.
- Repeating table headers; page numbering; consistent column widths; long descriptions wrap; currency aligns right; no clipping; totals/signature block kept together where feasible.
- Never print navigation, buttons, toasts, status badges or internal debugging panels.

## Document sections
Implement configurable templates (only relevant populated sections shown):
1. Claim cover/header with minimum necessary patient/claim fields.
2. Hospital bill summary and service-category reconciliation table.
3. Procedure/investigation/service lines with code/rate/source and review state.
4. Separate Pharmacy, IP Pharmacy, OT Pharmacy, Cathlab/OT/Ward consumables annexures.
5. Approved rule/deduction calculation sheet only if a source-approved policy engine result exists; otherwise show “NOT CALCULATED — policy/rate verification pending”.
6. Unlisted/review items annexure, never hidden.
7. Supporting document checklist, declared totals vs computed totals, page references and reviewer sign-off.

Do not present the generated output as an official government form unless the exact current official template and source are supplied. Clearly mark as a configurable preparation draft until verified.

## Rendering implementation
- Use a separate print template/renderer rather than mutating the interactive page's HTML.
- Escape all source descriptions and fields. Use deterministic ordering and repeated headers.
- Keep `bill_format_rules.py` as the source of margin validation/formatting logic. Add a template version ID and format configuration version to every generated preview.
- Provide print preview, print dialog and safe “export draft” behavior only after server validation. If native PDF generation is added, choose a maintained tool with a clear runtime dependency and test it on Windows; do not declare export working until a real generated PDF has been inspected.
- Browser `window.print()` is not equivalent to verified PDF output. If automated browser tooling isn't present, document a manual multi-page print test and state it wasn't automated.

## Required layout tests
Synthetic document with 3+ pages, long medicine descriptions, 25+ rows, merged row expanded to provenance, no rates available, no official policy, totals mismatch, long patient/claim ID, all margin presets, top reserve on each page, repeated headers, signature at page boundary and malicious HTML in row description.

## Acceptance
- Margin values round-trip through UI/API/backend.
- Unusable geometry is blocked with a clear message.
- Screen-only UI elements do not print.
- The output clearly distinguishes original billed amount from any separately verified calculation.
- Print/PDF status in README matches what was actually tested.
- Commit `feat: create validated A4 claim draft and annexure rendering`.
