# PHASE 13 — Final release gate, evidence report and handover

Apply the Master Engineering Contract. This is a release audit; do not mark the system production-ready simply because the UI looks polished or tests pass.

## Pre-release actions
1. Inspect full Git diff/history and verify each intended phase has a separate commit.
2. Run full unit/API suite, evaluation harness, static checks, and browser/print checks where actual tools are available.
3. Build a feature matrix: functional, partial, demo, blocked by source evidence, not implemented.
4. Confirm UI, API health/config, README, JSON config and tests agree about system capabilities.
5. Confirm no patient data, PDFs, extracted JSON, local database, access token, `.env`, screenshots of claims, temporary files or generated artifacts are tracked.
6. Confirm registry sources and every active catalogue/rule have provenance and validity dates. If Railway policy evidence remains absent, the policy/rate engine stays disabled, and that becomes a release blocker for any real financial calculation.
7. Confirm all print margins, multi-page layouts and totals/reconciliation gates have been tested; list anything that needs human print-preview verification.
8. Run the clean-install documented commands.
9. Verify no scheme other than Railway is selectable as an active workflow; BHEL/ECHS are future adapters only.

## Release states
Choose exactly one and explain why:
- `DEVELOPMENT_BASELINE_VERIFIED`
- `INTERNAL_REVIEW_READY`
- `CLAIM_DRAFT_WORKFLOW_READY` (only if actual end-to-end draft flow works)
- `NOT_READY_BLOCKED`

Do not use `PRODUCTION_READY` unless deployment architecture, authentication/authorization, privacy/retention, operational monitoring, backups/recovery, security review, official policy/rate validation and end-to-end acceptance are explicitly implemented and evidenced.

## Required handover report
Create `docs/RELEASE_READINESS.md` including:
- commit SHA and version;
- environment/runtime requirements;
- feature matrix;
- commands actually run and exact results;
- test counts and any skipped tests with reason;
- screenshots or browser traces only if actually captured;
- active source catalogue/rule versions and source links/document hashes;
- known limitations and operational risks;
- manual owner verification checklist;
- rollback instructions and migration notes;
- precise list of missing official Railway documents needed to enable rates/deductions;
- next 3 highest-value follow-up tasks.

## Acceptance
The release state follows evidence, not optimism. If anything critical is unverified, retain `NOT_READY_BLOCKED` or `INTERNAL_REVIEW_READY` and state the blocking evidence. Commit `docs: publish verified release readiness and handover`.
