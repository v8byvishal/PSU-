# PHASE 1 — Baseline audit, architecture map and stabilization

Apply the Master Engineering Contract. Audit the current repository and then implement only justified foundational fixes.

## Objective
Establish a trustworthy baseline for the actual starter so later phases can be measured. Do not redesign the entire app in this phase.

## Required inspection
- `git status --short`, branch, latest commit and repository tree.
- Python version and installed versions for requirements.
- `README.md`, `README_HINGLISH.md`, `SOURCE_MAP.md`, `docs/*`, `.gitignore`, GitHub workflow, every current test.
- Frontend script loading order and IDs/event handlers; all API routes and request/response shapes.
- Parser, print rules, config and code registry shape/count/source notes.
- Identify every action that uses demo/static values, every missing or broken control, and every statement that might misleadingly imply a government rule is implemented.

## Implement
1. Run `python -m unittest discover -s tests -v` before changes and save the exact baseline in a non-sensitive report (for example `docs/phase-reports/phase-01-baseline.md`). Do not include extracted bill text.
2. Fix only reproducible foundational issues: broken paths/imports, missing static assets, mismatched API contract, incorrect `.gitignore`, or misleading status labels. Do not invent policy logic.
3. Add/update a machine-readable capability status so UI/docs/API agree about what is real: text PDF extraction yes; OCR no unless implemented; rate catalogue verified no; Railway policy engine no; persistence/auth/submission no unless implemented.
4. Ensure app binds only to loopback by default, configuration paths resolve relative to the repository, and errors are safe.
5. Create `docs/ARCHITECTURE.md` and `docs/DATA_FLOW.md` diagrams if absent/outdated: browser → local API → temporary PDF → extraction → evidence payload → reviewer.
6. Update README's “works” and “not implemented” sections to match tests and actual code exactly.

## Tests / acceptance
- Existing test baseline reported; post-change full suite passes or each failure is explained and resolved before completion.
- `GET /api/health` explicitly reports `official_rates_connected=false`, `railway_policy_engine_connected=false`, `persistent_claim_storage=false` unless the corresponding feature was genuinely implemented and tested.
- `/` and `/assets/...` return the correct files.
- No `*.pdf`, real bill JSON, database, secret, `.env` or generated build artefact is tracked.
- No production claim-approval wording in current UI/API.
- `git diff --check` passes; run `git status` and inspect all changes.

## Deliverables
- Updated architecture/data-flow docs and capability matrix.
- Regression tests for every fix.
- Commit `chore: establish verified Railway starter baseline` (or a similar descriptive message).
- Phase report with exact baseline vs final counts, changed files and unresolved issues.
