# PHASE 10 — Security, privacy and local runtime hardening

Apply the Master Engineering Contract. Do a threat model first, then implement mitigations that match this local-first app. Do not expose a dev server as a production service.

## Threat model
Cover malicious/malformed PDF, PDF parser resource exhaustion, oversized uploads, path tricks, HTML/script injection from PDF text, cross-origin browser requests, CSRF-like local-network attacks, sensitive error messages, accidental logs, generated JSON leaks, repository leakage, unsafe rule config/import, dependency compromise and accidental remote binding.

## Required controls
- Loopback bind by default and a startup assertion/warning if host is configured to a non-loopback address. No public deployment feature in this phase.
- Strong server-side MIME/signature/parse checks; configurable upload/page/time budgets; temp-file privacy and cleanup on every path; limit concurrent parses or document why concurrency is safe.
- Don't save PDFs or extracted data by default. Never include PHI or PDF snippets in logs. Add test capture ensuring logged messages do not contain synthetic secret canaries.
- No-store headers on sensitive API endpoints. `nosniff`, restrictive referrer policy and an appropriate CSP where compatible with current assets.
- Safe exception handling: generic client error + internal non-PHI correlation ID; don't expose absolute paths or stack traces.
- Strict JSON/Pydantic schema validation; whitelist settings; do not allow `eval`, arbitrary formulas, command execution, user-controlled filesystem paths or dynamic imports from imported catalogue/policy files.
- Validate `Origin`/`Host` where relevant for loopback-only state-changing endpoints; make CORS policy explicit (not permissive wildcard). Document why same-origin local UI is the supported topology.
- Add dependency vulnerability/audit step using a tool only if available/appropriate; don't claim audit ran without output.
- Review `.gitignore` and `git status`; scan diffs for `.env`, keys, PDFs, DBs, output JSON and generated cache.
- Include a clear local-data cleanup command/UX if any persistent drafts are implemented. Explain deletion, backups and residual filesystem limits honestly.

## Security tests
Test non-PDF, wrong signature, malformed/encrypted PDF, oversized body, too many pages, temp cleanup on all exceptions, hostile PDF row text, path-like filename, Origin/Host rejection according to design, no-store/security headers, no sensitive canary in logs and disabled remote bind.

## Acceptance
Security controls are documented and tested; no claim of production certification. Any uncovered remote-deployment requirements are written into `docs/SECURITY.md` as blocking items. Commit `security: harden local processing and data boundaries`.
