# PHASE 4 — Canonical claim data model, editable rows and draft lifecycle

Apply the Master Engineering Contract. Build on existing parse output; do not replace the parser's evidence structure with a flattened table.

## Objective
Create a typed, versioned canonical model so extracted rows can be reviewed and corrected safely before any claim rules run.

## Model requirements
Define a stable schema for:
- `ClaimCase`: internal UUID, payer/pathway label (initially Indian Railways only), provider label, encounter/admission/discharge dates, claim reference, source file metadata hash/size (not raw PDF storage), status and schema version.
- `PatientFields`: only fields allowed by the current allow-list and actually needed for claim preparation; each field has a value, source evidence and reviewer override audit. Never store excluded phone/address/PAN/GSTIN by default.
- `SourceDocument`: document ID, kind, filename-safe label, hash, page count, ingestion time and retention state. Do not persist original bytes by default.
- `BillLine`: source row IDs/evidence, category, exact raw text, normalized description, quantity/unit, hospital rate and amount, catalogue candidates, selected mapping, reviewer override, confidence/status and line-level notes.
- `SourceEvidence`: page, block/line ID, source snippet with configured redaction policy, bounding box if available, extractor version and timestamp.
- `ReviewAction`: who/what/when and before/after hashes or safe field-level difference; never record full patient data in logs.
- `ValidationIssue`: stable code, severity, source location, blocking/nonblocking flag and resolution state.

## Editable workflow
- Display actual extracted rows in an editable grid with source evidence drawer/side panel.
- Editing a description or quantity must not erase the original extracted value; store original and reviewed values separately.
- Every correction requires a human action and creates a reversible review event. Support undo for in-memory changes.
- Never silently set a missing value to zero. Empty, unknown, not applicable and verified zero are distinct states.
- Add field validation and cross-field checks: admission/discharge order, quantities, unit presence, money parseability, duplicate row ID and missing evidence.
- Re-parsing a file creates a new extraction version; it must not silently overwrite a manually reviewed version.

## Persistence boundary
For this phase, in-memory drafts are acceptable if persistence security is not yet designed. Do not add plain-text patient-data storage casually. If durable drafts are implemented, first document local-only access, DB location, file permissions, deletion/retention, backup behavior, migration and test isolation; keep the DB outside tracked source and in `.gitignore`. Do not claim encryption if none exists.

## API contract
Add documented endpoints for create draft, retrieve current in-memory draft, update reviewed fields, undo last edit and clear draft (only if safe and fully implemented). Require schema validation, optimistic version/revision checks to prevent stale overwrites, and safe error handling. The API remains loopback-only.

## Tests
- Missing vs zero; Decimal values; invalid dates; edits preserve originals; undo works; duplicate row IDs rejected; conflicting updates return safe conflict; source evidence remains; reparse doesn't overwrite edits; clearing one case does not clear another; no sensitive data in logs or Git fixtures.

## Acceptance
- Reviewer can correct an extracted line and see the source value and reviewed value side by side.
- Every edit has a traceable event and can be undone while the session is active.
- No policy/rates is invoked during editing.
- Commit `feat: add canonical claim model and reviewable line editor`.
