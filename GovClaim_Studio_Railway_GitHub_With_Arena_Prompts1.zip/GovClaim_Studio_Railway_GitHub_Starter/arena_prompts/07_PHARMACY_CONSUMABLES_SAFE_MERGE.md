# PHASE 6 — Pharmacy/consumables item sections and reversible duplicate merge

Apply the Master Engineering Contract. The goal is safe consolidation and presentation, not maximizing merged-row count.

## Categories
Support separate sections for the categories found in source bills, including IP Pharmacy, Pharmacy, OT Pharmacy, Cathlab Consumables, OT Consumables, Ward Consumables and Other Consumables. Preserve any original source category and allow a reviewer to reclassify with an audit event. Do not lose the source category because of a display grouping.

## Merge eligibility
A duplicate merge can only be proposed when the items are compatible. Use explicit normalized comparison fields, such as:
- canonical item identity/code and source-catalogue version;
- medicine strength/concentration, formulation, dosage form and route where available;
- product/device model/specification and pack size where relevant;
- billing unit, currency, rate/tariff basis, taxes/discounts, service date or relevant claim period;
- inclusion/charge category and package status;
- batch/serial/implant traceability where required by the source data or workflow.

If any material attribute is unknown or conflicts, mark `POSSIBLE_DUPLICATE_REVIEW` rather than merge automatically. Description similarity alone is insufficient. Never merge different strengths, formulations, package sizes, units or tariff bases.

## Review UX
- Display group proposals with match reasons and the original rows side by side.
- Show original row IDs, document/page/line evidence, original quantity/rate/amount and computed aggregate.
- Provide `Accept merge`, `Keep separate`, `Undo merge` and reviewer reason. The default action is not to merge.
- Accepted merge retains original line rows, maps a new aggregate to all its sources and stores the reviewer action. Undo restores the exact former grouping.
- Reconciliation: where unit/rate compatibility is established, use Decimal and compute quantity × rate; separately preserve original source amounts. If source sums don't reconcile within configured tolerance, flag and block finalization rather than rewrite them.
- Keep detail view and print annexure able to expand a merged group into its original source rows.

## Totals rules
- Department/summary totals, line subtotals, deposits, refunds, discounts, taxes, patient payables and hospital gross totals must not be conflated.
- Deduplicate only where the same original row was accidentally ingested twice and there is evidence of the duplicate source record. Two separate administrations on different dates can be legitimate and must not be removed merely because description matches.
- If legacy pharmacy and consumable aggregates exist, use them only as reconciliation evidence. Do not add them to detail-derived totals if they summarize those same rows.

## Tests
- Identical compatible drug lines can be proposed and merged by explicit reviewer action.
- Same name but different strength/form/unit/rate/pack size cannot be auto-merged.
- Merge/undo round-trip preserves quantities, money, source references and original row ordering.
- Conflicting source amount and recomputed amount blocks finalization with delta.
- Repeated treatment on different dates remains distinct unless policy says otherwise.
- Summary + detail not double-counted.

## Acceptance
No duplicate merge modifies the bill invisibly. Every merged group can be expanded, traced and undone.
Commit `feat: add reversible pharmacy and consumables merge review`.
