# PHASE 12 — Reliable Windows developer experience and local packaging

Apply the Master Engineering Contract. Target the user's Windows + PowerShell environment first. The goal is an easy and reproducible local run, not premature public deployment.

## Required deliverables
- Clear, tested `README.md` and Hinglish guide.
- `requirements.txt` must be reproducible and intentionally version-bounded; if adding a lock file, use a supported reproducible method and document the Python/platform target.
- `scripts/setup_windows.ps1`, `scripts/run_windows.ps1`, `scripts/test_windows.ps1` or equivalent, with safe PowerShell behavior and useful error messages.
- An optional `.bat` launcher is allowed only if it preserves exit codes and doesn't swallow stderr. Do not require admin privileges.
- Startup performs a fast dependency/config check and binds to `127.0.0.1` only. Print the local URL and how to stop the process. Don't auto-open a remote network endpoint.
- Document the expected folder structure after ZIP extraction. Don't add built binaries/venvs/node_modules into Git.
- Ensure all config/data paths work when launched from repository root and a different current working directory.
- Provide a reset/cleanup command for synthetic outputs/drafts without deleting source files. It must never accidentally delete arbitrary user paths.
- Use health/config endpoints as the authoritative feature-status source; make unsupported feature messages consistent throughout UI/docs.

## Optional desktop packaging boundary
Do not add Electron, PyInstaller, Docker or a cloud service just for appearance. Only add a packager when requested or when the current local web app is verified and the dependency/build cost is justified. If packaging is added later, make a separate phase with exact build/test steps and code signing/antivirus caveats.

## Verification
- Create a fresh venv and install dependencies from scratch where environment permits.
- Run the documented server command and API health endpoint.
- Run tests using the documented command.
- Test paths with spaces in repo folder name.
- Confirm Ctrl+C exits cleanly and logs no patient contents.
- Validate error exit codes for setup/test scripts.

## Acceptance
A new developer can follow the guide from a clean Windows machine without guessing commands, but the report must clearly distinguish tests actually performed in current environment from tests the owner must run locally.
Commit `build: improve Windows local setup and quality commands`.
