# PHASE 5 — Versioned code catalogue and explainable item matching

Apply the Master Engineering Contract. Do not transform the existing CGHS code-description snapshot into a verified Railway tariff.

## Objective
Make catalogue ingestion and item-code matching explicit, provenance-aware and reviewable. The only current registry is an identity/reference snapshot; its official status and effective dates are not established.

## Catalogue model
Each imported catalogue version must include:
- `catalogue_id`, payer/scheme scope, source title, issuer/authority, source document or URL/path, document checksum, import timestamp, source issue/effective dates if evidenced, version label, parser version, reviewer approval and active status.
- Each item: exact source code, official description, specialty/category, unit, rate (optional and kept separate from identity), validity dates, source page/sheet/row, source quote, and import warnings.
- Store source data and normalized values separately. Don't mutate original codes/descriptions while normalizing.
- Code/description registry and tariff/rate schedule are separate concepts. A row without an evidenced rate must not imply a price of zero.

## Matching workflow
1. Exact code match only when code exists in the chosen active catalogue version and applicable scope matches.
2. Description normalization may generate candidates (case, punctuation, whitespace, common abbreviations) but must preserve original label.
3. If using fuzzy scoring, keep it a reviewer ranking signal, return the scoring features/explanation and candidates; do not automatically approve.
4. Do not use an LLM/embeddings as final mapper. If later offered as a suggestion system, require human approval and retain evidence.
5. Show candidate code, source description, source/version/effective date, similarity reasons, conflicts and whether the candidate is eligible to select.
6. If no exact/acceptable match: `UNLISTED`. If multiple candidates or evidence conflict: `REVIEW_REQUIRED`. Never invent or autocomplete a code.
7. Manual override requires reviewer identity/session, reason, timestamp, previous value, chosen catalogue item/source and undo path.

## Import sources
- Support a staged import from CSV/JSON first. Only add XLSX/PDF import if a real need exists and the imported headers/columns are mapped explicitly.
- Show a preview and field mapping step before activation. Imported files do not become active catalogues automatically.
- Validate duplicates, conflicting code descriptions, overlapping effective dates, currency formats, missing units and source metadata.
- Keep data import idempotent by file checksum and explicit version key.

## Railway-specific guard
A catalogue is not “Railway approved” just because its filename contains CGHS/Railway or because its code appears in an old bill. If a Railway circular points to a specific CGHS schedule for a defined pathway, preserve that exact rule reference and scope before making the schedule selectable for that case. Do not activate an assumed global mapping.

## Tests
Exact match; invalid code; duplicated code; same description with different units; effective-date overlap; catalog source not approved; expired rate; code exists but no rate; ambiguous description; manual override audit; unknown item remains unlisted; no match operation calculates payable amount.

## Acceptance
- Catalogue preview → mapping → validation → human approval → active version is a full explicit workflow.
- Candidate matching explains why each result appeared.
- Existing code snapshot remains marked unverified/informational until reviewed against an official source.
- Commit `feat: add versioned source catalogue and reviewable code matching`.
