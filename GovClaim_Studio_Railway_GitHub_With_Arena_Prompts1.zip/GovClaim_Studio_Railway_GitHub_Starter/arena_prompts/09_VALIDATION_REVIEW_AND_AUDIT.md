# PHASE 8 — Claim validation gates, reviewer queue and audit trail

Apply the Master Engineering Contract. Add explicit workflow states and meaningful review actions, without suggesting that an internal review equals government approval.

## State machine
Design and document legal transitions. Suggested states:
`DRAFT` → `INGESTED` → `EXTRACTION_REVIEW` → `MAPPING_REVIEW` → `RULE_REVIEW` (only if policy engine connected) → `VALIDATION_FAILED` or `READY_FOR_HUMAN_REVIEW` → `HUMAN_REVIEWED` → `EXPORTED_DRAFT`.
A source edit invalidates downstream validation/calculation results and returns the case to the appropriate review state. Do not use `CLAIM_APPROVED` as an app-generated status.

## Validation engine
Create a registry of validation rules with stable ID, message, severity (`INFO`, `WARNING`, `BLOCKING`), condition, evidence, resolution guidance and whether reviewer override is allowed. Include:
- missing/conflicting essential header fields;
- invalid admission/discharge dates;
- items without description, unit, quantity, amount or evidence;
- unlisted/ambiguous catalogue mappings;
- unverified/expired tariff and policy rules;
- quantity × rate mismatch;
- duplicate/merge review unresolved;
- summary/detail double-count warning;
- declared gross/discount/deposit/refund/net totals mismatch;
- required supporting-document checklist missing;
- stale validation after edits;
- print geometry/page layout warnings.

Validation must be idempotent and must not mutate source line values. Blocking issues prevent finalization/export. Nonblocking warnings require explicit acknowledgement if configured. Never let a browser-sent `is_valid=true` bypass server validation.

## Audit trail
- Record reviewer edits, code selection/override, merge accept/undo, catalogue version change, policy decision, validation resolution and export event.
- Use immutable append-only events or hash-chained event records where practical; document precisely what is and is not tamper-evident. Do not claim cryptographic immutability without a tested key/storage design.
- Keep sensitive values out of application logs. Audit event should reference field names/record IDs and before/after hashes or a redacted diff, not dump the entire patient claim.
- Every event includes unique ID, case ID, actor/session identity (do not invent identity if authentication not present), UTC timestamp, action, reason and entity revision.

## Export gate
The backend—not only UI—must require all configured blocking checks to pass, source version snapshots to remain current, no unresolved mandatory review items, and an explicit human confirmation. If approved policy is absent, label the output “Review Draft — Policy/Tariff Not Verified” and prohibit a misleading finalized/admissible status.

## Tests
Invalid state transition; editing invalidates validations; blocking issues prevent export; nonblocking acknowledgements; audit events for edit/override/merge/export; no raw patient details in logs; validation runs deterministically; stale version conflicts are handled; browser cannot bypass backend gate.

## Acceptance
The UI shows a compact actionable issue list linking directly to each affected field/row. The server enforces the same gates. Commit `feat: add claim validation and review audit trail`.
