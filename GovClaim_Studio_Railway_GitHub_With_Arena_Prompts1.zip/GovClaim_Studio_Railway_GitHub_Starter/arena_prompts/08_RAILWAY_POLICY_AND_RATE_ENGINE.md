# PHASE 7 — Evidence-gated Railway tariff and policy-rule engine

Apply the Master Engineering Contract. This phase may build the engine and its disabled interface even if official policy documents are not present. Do not fabricate any policy or rate.

## Objective
Create deterministic, dated, testable rule execution that cannot run unless the relevant official source record is approved and all case-scope conditions are satisfied.

## Separate three layers
1. **Catalogue identity**: code and description.
2. **Tariff/rate version**: monetary amount, unit, applicable location/tier, ward/category, provider eligibility and effective period, each sourced to an official record.
3. **Policy/admissibility rules**: package inclusion, deductions, caps, ceilings, exclusions, sequencing, formula and scope.

Never assume one of these layers implies the others.

## Policy rule schema
Each rule must contain:
- stable `rule_id`, name, rule kind and status (`DRAFT`, `REVIEW_REQUIRED`, `APPROVED`, `ACTIVE`, `EXPIRED`, `REVOKED`);
- issuing authority, official document ID/title and source URL or managed source path, circular number, clause/paragraph, exact page/section, document hash;
- issue date, effective-from/to dates, payer/pathway, clinical/service scope, hospital type, provider/location tier, room/ward eligibility and any required preconditions/exclusions;
- input fields and their evidence/validation requirements;
- calculation base, formula representation, operation order/priority, rounding stage/mode/precision, caps/floors, interaction/stacking rules, package-inclusion behavior and conflict resolution;
- test fixture references, approving reviewer, approval date and change history.

If any mandatory field is absent, keep the rule disabled. Use typed enums and a restricted formula DSL/config schema; never evaluate arbitrary Python, `eval`, shell or executable expressions from a rules file.

## Rate resolver
- Select a rate only if the catalogue is verified, source approved, valid on applicable service/admission date, and every eligibility dimension is known and matches.
- Return the chosen rate, unit, version, source/page/row, effective date, selection explanation and conflicts.
- If multiple rates could apply, no rate applies, scope facts are missing, effective dates are ambiguous or source is not approved: no automatic price; return `RATE_REVIEW_REQUIRED`.
- Store rate in Decimal/paise and define currency and rounding policy explicitly.

## Rule execution
- Deterministic, side-effect-free evaluation; same input snapshot + same approved rule versions must yield same output.
- Each calculation result includes the exact input fields and evidence refs, selected rate version, ordered rule IDs, pre/post amounts, formula/operation details, rounding and result status.
- Keep hospital billed amount, reference tariff, package-included/non-separately-claimable amount, rule deduction, allowed/admissible candidate and final reviewed amount separate.
- Do not double-count summary totals or included services.
- 50%, 25%, oxygen duration and any other deduction remain inactive unless exact official evidence and tests are supplied. Do not create examples with made-up active rules.
- Require a human reviewer to approve calculation results before a claim pack is finalized. Software never says “government approved” or guarantees reimbursement.

## Missing inputs
If no verified Railway circular/tariff dataset is present in the repository, create the schema, import/approval workflow, status endpoints and tests, but keep all rate/policy execution disabled and show a clear reason. Add a `POLICY_EVIDENCE_CHECKLIST.md` enumerating the precise missing official documents/fields for the owner to supply.

## Tests
Invalid/incomplete rule cannot activate; date boundaries; scope mismatch; missing city/ward/provider attributes; expired/revoked rule; conflicting rules; deterministic rule order; Decimal rounding; caps/floors; inclusion prevents double charge; approved rate source citation in result; rule result changes only when the approved version changes; all unverified examples result in no calculated admissible amount.

## Acceptance
Health/config endpoint accurately says whether a verified rate catalogue and approved Railway rules are connected. No default/placeholder tariff or deduction can accidentally execute. Commit `feat: add source-gated Railway rate and policy engine`.
