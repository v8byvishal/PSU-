# PHASE 3 — Production-minded PDF ingestion and evidence-preserving extraction

Apply the Master Engineering Contract. Improve `railway_bill_read_rules.py` and `/api/claims/parse` without pretending extraction is OCR or adjudication.

## Input and resource controls
- Accept one PDF only in this phase; check extension, MIME as a secondary signal, `%PDF-` signature, parseability and encryption status.
- Use a configurable maximum upload size and a configurable maximum page count. Reject files outside limits with safe, actionable status codes.
- Do not trust submitted filenames or MIME. Do not use filename in a filesystem path except a sanitized display label.
- Ensure temp files are removed on success, parse error, request cancellation/exception and all other exit paths. If a byte stream approach safely avoids disk, document it; otherwise use a private temp path.
- Do not log raw text, names, IDs, phone numbers, address, full filename or PDF contents. Log only request ID, size, page count, duration, outcome code and other approved non-PHI metadata.
- Disable caching of sensitive responses; never persist source PDFs by default.

## Extraction contract
Create/update a versioned response schema that includes:
- `schema_version`, `reader_version`, `source_file_label` (safe display-only name), `pages_read`, `pages_with_text`, `pages_without_text`, `ocr_performed: false`, warnings and overall `REVIEW_REQUIRED` status.
- Minimal required header fields with `value`, `confidence` (calibrated label, not made-up numeric certainty), and `evidence[]` containing page, raw source snippet, coordinates/block ID where available, and extraction method.
- Each service row has stable request-local `row_id`, source page, source block/line, exact original row text, detected section, extracted description, original code tokens, quantity/unit/rate/amount candidates as strings parseable into Decimal, and per-field evidence.
- Code resolution must preserve every occurrence and reason: exact valid registry token, unknown token, ambiguous composite token, no code seen. Never turn a guessed or invalid code into accepted code.
- Distinguish hospital summary/category totals from detailed billed rows and their subtotals. Every total candidate must contain source location, amount, role (`summary`, `detail`, `subtotal`, `payment`, `deposit`, `patient_payable`, `unknown`) and confidence/evidence.

## Layout cases to address
- Single and multi-page PDFs; section header on previous page; line wraps; multi-column text; negative/discount lines; repeated header/footer; empty pages; text extraction yielding zero text (likely scanned image); rotated pages; malformed/encrypted PDFs; amounts with Indian separators; page breaks inside a department.
- Preserve page order and original source text. Extraction normalization must not overwrite source text.
- Detect scanned/image-only pages and return `OCR_REQUIRED`/`NO_TEXT_EXTRACTED`; do not claim OCR ran.
- Keep `legacy_pharmacy_reading`, `legacy_consumables_reading` and `legacy_room_rent_candidates` clearly labelled as legacy informational evidence, not payable calculations.

## Implementation style
- Add Pydantic models or JSON-schema validation for the output, aligned with current stack.
- Keep money parsing in Decimal and serialize deterministically as decimal strings.
- Return safe error codes such as `INVALID_PDF`, `PASSWORD_PROTECTED_PDF`, `UPLOAD_TOO_LARGE`, `TOO_MANY_PAGES`, `NO_TEXT_EXTRACTED`, `PARSE_FAILED`; never include raw tracebacks or local paths in responses.
- Keep reader deterministic and local. Do not call external AI services.

## Test matrix
Generate synthetic PDFs in memory; never store real bills. Include each edge case above. Specifically test file-size boundary, page-count boundary, invalid signature, a PDF signature with malformed content, password-protected PDF, empty/scanned-style page, section split over pages, multiline line item, totals in separate summary, cleanup after exceptions, no-store headers, output schema stability and XSS strings.

## Acceptance
- `/api/claims/parse` is deterministic for the same synthetic PDF.
- Every extracted value can point to evidence or has a clear `not_found`/`derived` reason.
- No tariff/admissible amount/deduction is produced.
- Temp file cleanup test passes on success and exception.
- `README` accurately says text extraction only; OCR status is explicit.
- Commit `feat: harden local PDF ingestion and evidence extraction`.
