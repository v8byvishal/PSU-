"""
Bill format, A4 print margins and billing-adjacent advanced options
derived from the supplied HFOS v5.0 application/report.

This is a reusable rule/config helper, not a statement of official Railway policy.
Rates and claim deductions are intentionally outside this module.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from html import escape
from typing import Any, Mapping, Optional, Sequence
import json
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
DEFAULT_FORMAT_CONFIG = PACKAGE_DIR / "config" / "bill_format_settings.json"

A4_WIDTH_MM = Decimal("210")
A4_HEIGHT_MM = Decimal("297")
A4_WIDTH_PT = Decimal("595.28")
A4_HEIGHT_PT = Decimal("841.89")
POINTS_PER_MM = Decimal("72") / Decimal("25.4")
MM_PER_INCH = Decimal("25.4")

DEFAULT_PRINT_MARGINS_MM = {"top": 60, "bottom": 20, "left": 12, "right": 12}
PRINT_PRESETS_MM = {
    "standard_letterhead": {"top": 60, "bottom": 20, "left": 12, "right": 12},
    "short_letterhead": {"top": 45, "bottom": 18, "left": 12, "right": 12},
    "plain_paper": {"top": 15, "bottom": 15, "left": 12, "right": 12},
}
LEGACY_CGHS_PRIORITY_CODES = ("CC001", "WC001", "CN002")

DEFAULT_ADVANCED_OPTIONS = {
    "qr_verification": True,
    "amount_in_words": True,
    "duplicate_detection_before_save": True,
    "mandatory_field_validation": True,
    "amount_reconciliation": True,
    "rate_lock_outside_admin_mode": True,
    "manual_override_requires_reason": True,
    "draft_autosave": True,
    "restore_last_draft": True,
    "pdf_preview": True,
    "save_pdf_as": True,
    "download_pdf": True,
    "print": True,
    "save_only": True,
    "browser_print_fallback": True,
    "pdf_history": True,
    "monochrome_print": True,
    "legacy_cghs_priority_enabled": False,  # must not be silently inherited as Railway policy
    "hospital_name_in_signature": False,
}


def load_format_config(path: str | Path = DEFAULT_FORMAT_CONFIG) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _decimal(value: Any, fallback: Optional[Decimal] = None) -> Optional[Decimal]:
    if value is None or value == "":
        return fallback
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        return fallback
    return result if result.is_finite() else fallback


def validate_margins(margins: Optional[Mapping[str, Any]] = None) -> dict[str, Any]:
    """Validate margin values; do not silently clamp user-selected settings."""
    src = dict(DEFAULT_PRINT_MARGINS_MM)
    if margins:
        for key in src:
            if key in margins:
                src[key] = margins[key]
    parsed: dict[str, Decimal] = {}
    errors: list[str] = []
    for key in ("top", "bottom", "left", "right"):
        value = _decimal(src.get(key))
        if value is None:
            errors.append(f"{key} margin must be a finite number.")
            continue
        if value < 0:
            errors.append(f"{key} margin cannot be negative.")
        parsed[key] = value

    if errors:
        return {"valid": False, "errors": errors, "margins_mm": src, "geometry": None}

    usable_w = A4_WIDTH_MM - parsed["left"] - parsed["right"]
    usable_h = A4_HEIGHT_MM - parsed["top"] - parsed["bottom"]
    if usable_w * POINTS_PER_MM < Decimal("120"):
        errors.append("Left/right margins leave less than 120 pt of usable width.")
    if usable_h * POINTS_PER_MM < Decimal("120"):
        errors.append("Top/bottom margins leave less than 120 pt of usable height.")
    if parsed["top"] + parsed["bottom"] >= A4_HEIGHT_MM:
        errors.append("Top + bottom margins consume the whole page.")
    if parsed["left"] + parsed["right"] >= A4_WIDTH_MM:
        errors.append("Left + right margins consume the whole page.")

    geometry = {
        "usable_width_mm": str(usable_w),
        "usable_height_mm": str(usable_h),
        "usable_width_pt": str((usable_w * POINTS_PER_MM).quantize(Decimal("0.01"))),
        "usable_height_pt": str((usable_h * POINTS_PER_MM).quantize(Decimal("0.01"))),
        "top_reserve_mm": str(parsed["top"]),
        "same_top_reserve_on_continuation_pages": True,
    }
    return {
        "valid": not errors,
        "errors": errors,
        "margins_mm": {key: str(value) for key, value in parsed.items()},
        "geometry": geometry,
    }


def margin_preset(preset_id: str) -> dict[str, int]:
    if preset_id not in PRINT_PRESETS_MM:
        raise KeyError(f"Unknown print preset: {preset_id}")
    return dict(PRINT_PRESETS_MM[preset_id])


def margin_to_points(value_mm: Any) -> Decimal:
    value = _decimal(value_mm)
    if value is None or value < 0:
        raise ValueError("Margin must be a finite non-negative number")
    return (value * POINTS_PER_MM).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def build_print_css(margins: Optional[Mapping[str, Any]] = None) -> str:
    """Return shared A4 browser-print CSS; same margins apply to all pages."""
    result = validate_margins(margins)
    if not result["valid"]:
        raise ValueError("; ".join(result["errors"]))
    m = result["margins_mm"]
    return f"""
@media print {{
  @page {{ size: A4 portrait; margin: {m['top']}mm {m['right']}mm {m['bottom']}mm {m['left']}mm; }}
  html, body {{ margin: 0 !important; padding: 0 !important; background: #fff !important; color: #000 !important; }}
  #printRoot {{ width: auto !important; background: #fff !important; color: #000 !important; }}
  #printRoot, #printRoot * {{ box-shadow: none !important; text-shadow: none !important; color: #000 !important; background: transparent !important; }}
  #printRoot table {{ width: 100%; border-collapse: collapse; page-break-inside: auto; }}
  #printRoot thead {{ display: table-header-group; }}
  #printRoot tfoot {{ display: table-footer-group; }}
  #printRoot tr {{ page-break-inside: avoid; break-inside: avoid; page-break-after: auto; }}
  #printRoot th, #printRoot td {{ border: 1px solid #000 !important; }}
  #printRoot .bill-totals, #printRoot .bill-footer {{ page-break-inside: avoid; break-inside: avoid; }}
}}
""".strip()


def format_rupees(value: Any) -> str:
    number = _decimal(value)
    if number is None:
        return ""
    rounded = number.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    negative = rounded < 0
    rounded = abs(rounded)
    whole = int(rounded)
    paise = int((rounded - Decimal(whole)) * 100)
    # Indian digit grouping: last 3 digits, then groups of 2 digits.
    digits = str(whole)
    if len(digits) <= 3:
        s = digits
    else:
        head, tail = digits[:-3], digits[-3:]
        groups = []
        while head:
            groups.insert(0, head[-2:])
            head = head[:-2]
        s = (",".join(groups) + "," if groups else "") + tail
    out = f"{s}.{paise:02d}"
    return "-" + out if negative else out


_ONES = [
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
    "Seventeen", "Eighteen", "Nineteen",
]
_TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]


def _two_digit_words(n: int) -> str:
    if n == 0:
        return ""
    if n < 20:
        return _ONES[n]
    return _TENS[n // 10] + ((" " + _ONES[n % 10]) if n % 10 else "")


def _integer_to_indian_words(n: int) -> str:
    if n == 0:
        return "Zero"
    parts = []
    for size, label in ((10_000_000, "Crore"), (100_000, "Lakh"), (1_000, "Thousand"), (100, "Hundred")):
        group = n // size
        if group:
            if size == 100:
                words = _ONES[group]
            else:
                words = _integer_to_indian_words(group) if group >= 10_000_000 else _two_digit_words(group)
            parts.append(f"{words} {label}")
            n %= size
    if n:
        parts.append(_two_digit_words(n))
    return " ".join(parts)


def amount_in_words_inr(value: Any) -> str:
    """Indian numbering words with paise; suitable for a bill caption."""
    amount = _decimal(value)
    if amount is None:
        raise ValueError("A valid amount is required")
    amount = amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if amount < 0:
        return "Minus " + amount_in_words_inr(-amount)
    rupees = int(amount)
    paise = int((amount - Decimal(rupees)) * 100)
    if rupees == 0 and paise == 0:
        return "Zero Rupees Only"
    parts = []
    if rupees:
        parts.append(_integer_to_indian_words(rupees) + " Rupees")
    if paise:
        parts.append(_two_digit_words(paise) + " Paise")
    return " and ".join(parts) + " Only"


def apply_row_order(rows: Sequence[Mapping[str, Any]], *, enable_legacy_cghs_priority: bool = False) -> list[dict[str, Any]]:
    """
    Keep source order by default. Legacy CGHS-only priority order is available
    as an explicit option but is disabled by default in the Railway profile.
    """
    result = [dict(row) for row in rows]
    if not enable_legacy_cghs_priority:
        return result
    rank = {code: i for i, code in enumerate(LEGACY_CGHS_PRIORITY_CODES)}
    indexed = sorted(
        enumerate(result),
        key=lambda pair: (rank.get(str(pair[1].get("code", "")).upper(), 99), pair[0]),
    )
    return [item for _, item in indexed]


def validate_bill_totals(rows: Sequence[Mapping[str, Any]], declared_total: Any, tolerance: Any = "0.01") -> dict[str, Any]:
    """Reconcile line amount sum to declared total; never silently alter either."""
    parsed_rows = []
    missing = []
    for idx, row in enumerate(rows, start=1):
        amount = _decimal(row.get("amount"))
        if amount is None:
            missing.append(idx)
        else:
            parsed_rows.append(amount)
    row_sum = sum(parsed_rows, Decimal("0.00")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    declared = _decimal(declared_total)
    tol = _decimal(tolerance, Decimal("0.01")) or Decimal("0.01")
    difference = None if declared is None else (declared - row_sum).quantize(Decimal("0.01"))
    return {
        "valid": declared is not None and not missing and abs(difference or Decimal("0")) <= tol,
        "row_sum": str(row_sum),
        "declared_total": str(declared) if declared is not None else None,
        "difference": str(difference) if difference is not None else None,
        "tolerance": str(tol),
        "rows_missing_amount": missing,
        "status": "PASS" if declared is not None and not missing and abs(difference or Decimal("0")) <= tol else "REVIEW_REQUIRED",
    }


def render_printable_bill_html(record: Mapping[str, Any], margins: Optional[Mapping[str, Any]] = None) -> str:
    """
    Render a monochrome preview of the HFOS-style bill format.
    It only presents supplied values; it does not set rates or calculate admissibility.
    `record` accepts patient{}, settings{}, rows[], total, words, credit, verification_code.
    """
    css = build_print_css(margins)
    patient = dict(record.get("patient") or {})
    settings = dict(record.get("settings") or {})
    title = escape(str(settings.get("bill_title", "Final - Bill")))
    prefix = escape(str(settings.get("bill_number_prefix", "")))
    rows = record.get("rows") or []

    def val(key: str) -> str:
        return escape(str(patient.get(key) or ""))

    table_rows = []
    for row in rows:
        amount = row.get("amount", "")
        table_rows.append(
            "<tr>"
            f"<td class='code'>{escape(str(row.get('code') or 'UNLISTED'))}</td>"
            f"<td>{escape(str(row.get('particular') or ''))}</td>"
            f"<td class='num'>{escape(format_rupees(row.get('rate')) if row.get('rate') not in (None, '') else '')}</td>"
            f"<td class='num'>{escape(str(row.get('quantity') if row.get('quantity') is not None else ''))}</td>"
            "<td>Rs</td>"
            f"<td class='num'>{escape(format_rupees(amount) if amount not in (None, '') else '')}</td>"
            "</tr>"
        )
    qr_text = escape(str(record.get("verification_code") or "")) if settings.get("qr_verification", True) else ""
    words = escape(str(record.get("amount_in_words") or amount_in_words_inr(record.get("total", 0)))) if settings.get("amount_in_words", True) else ""
    credit = escape(str(record.get("credit_line", settings.get("credit_line", ""))))
    total = escape(format_rupees(record.get("total", 0)))

    return f"""<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title>
<style>
body{{font-family:Arial,Helvetica,sans-serif;color:#111;background:#f3f4f5;margin:0}}
#screenPreview{{max-width:1100px;margin:20px auto;padding:24px;background:#fff;border:1px solid #d5d9de;box-shadow:0 8px 28px #00000012}}
#printRoot{{width:100%;color:#000;background:#fff}}
.bill-head{{padding:0 0 10px;border-bottom:1.4pt solid #000}}
.bill-head .title{{font-size:13.5pt;font-weight:700;text-align:center;margin:0 0 14pt;text-decoration:underline;text-underline-offset:5pt}}
.bill-meta{{display:grid;grid-template-columns:1fr 1fr;gap:6px 18px;font-size:9pt;margin:12pt 0 14pt}}
.lbl{{font-size:8.4pt}}
.items{{width:100%;border-collapse:collapse;table-layout:fixed;font-size:8.6pt;margin-top:12pt}}
.items th{{font-size:7.4pt;text-align:left;border-top:1.1pt solid #000;border-bottom:.6pt solid #000;padding:5pt}}
.items td{{border:0;border-bottom:.5pt solid #222;padding:5.5pt 5pt;vertical-align:middle;overflow-wrap:anywhere}}
.items th:nth-child(1),.items td:nth-child(1){{width:13.5%;text-align:left}}
.items th:nth-child(2),.items td:nth-child(2){{width:45.5%;text-align:left;white-space:normal}}
.items th:nth-child(3),.items td:nth-child(3){{width:13.5%;text-align:right}}
.items th:nth-child(4),.items td:nth-child(4){{width:7.5%;text-align:right}}
.items th:nth-child(5),.items td:nth-child(5){{width:4.5%;text-align:center}}
.items th:nth-child(6),.items td:nth-child(6){{width:15.5%;text-align:right}}
.items .num{{text-align:right;white-space:nowrap}}
.bill-totals{{padding-top:10pt;margin-top:8pt;border-top:1.1pt solid #000;page-break-inside:avoid;break-inside:avoid}}
.total-line{{display:flex;justify-content:space-between;margin-left:auto;width:58%;padding:7pt 6pt;border:1px solid #000;font-weight:700}}
.total-amt{{border-bottom:3pt double #000;padding-bottom:2pt}}
.words-line{{margin-top:9pt;font-size:9pt}}
.bill-footer{{display:flex;justify-content:space-between;align-items:flex-end;gap:10mm;padding-top:30pt;font-size:9pt;page-break-inside:avoid;break-inside:avoid}}
.signatory{{min-width:52mm;margin-top:20mm;border-top:1px solid #000;padding-top:7mm;text-align:right}}
.qr-code{{font-size:7pt;overflow-wrap:anywhere}}
@media screen and (max-width:700px){{#screenPreview{{margin:8px;padding:12px;overflow:auto}}.bill-meta{{grid-template-columns:1fr}}.items{{font-size:7.5pt}}}}
{css}
</style></head>
<body><main id="screenPreview"><section id="printRoot">
<div class="bill-head"><div class="title">{title}</div>
<div class="bill-meta">
<div><span class="lbl">BILL NO- </span><strong>{prefix}{val('bill_number')}</strong></div>
<div><span class="lbl">DATE:- </span><strong>{val('bill_date') or val('discharge_date')}</strong></div>
<div><span class="lbl">Patient Name:- </span><strong>{val('patient_name')}</strong></div>
<div><span class="lbl">AGE/SEX :- </span><strong>{val('age_sex')}</strong></div>
<div><span class="lbl">D.O.A - </span><strong>{val('admission_date')}</strong></div>
<div><span class="lbl">D.O.D - </span><strong>{val('discharge_date')}</strong></div>
</div></div>
<table class="items"><thead><tr><th>CGHS CODE</th><th>PARTICULAR</th><th style="text-align:right">RATE</th><th style="text-align:right">QTY</th><th></th><th style="text-align:right">TOTAL AMT</th></tr></thead>
<tbody>{''.join(table_rows)}</tbody></table>
<div class="bill-totals"><div class="total-line"><span>TOTAL</span><span class="total-amt">{total}</span></div>
{f'<div class="words-line">In Words- {words}</div>' if words else ''}</div>
<div class="bill-footer"><div>{credit}<br>Dated:- {val('discharge_date')}</div>
<div>{f'<div class="qr-code">Verification: {qr_text}</div>' if qr_text else ''}<div class="signatory">{('For: ' + escape(str(settings.get('hospital_name', ''))) + '<br>' if settings.get('hospital_name_in_signature', False) else '')}Authorised Signatory</div></div>
</div></section></main></body></html>"""


__all__ = [
    "A4_HEIGHT_MM", "A4_WIDTH_MM", "DEFAULT_ADVANCED_OPTIONS", "DEFAULT_PRINT_MARGINS_MM",
    "LEGACY_CGHS_PRIORITY_CODES", "PRINT_PRESETS_MM", "amount_in_words_inr", "apply_row_order",
    "build_print_css", "format_rupees", "load_format_config", "margin_preset", "margin_to_points",
    "render_printable_bill_html", "validate_bill_totals", "validate_margins",
]
