# Changelog

## 0.2.0 — Engineering prompt pack
- Added a 17-document phased Arena AI engineering prompt pack, from repository audit through release gate.
- Added strict rules for evidence-backed Railway policy/rate execution, source provenance, reversible merges, privacy, testing and handover.
- Updated README and Arena entry-point to use the sequential prompt workflow.
- Added no live Railway tariff or deduction rule.

## 0.1.0 — GitHub starter
- Split the full UI prototype into HTML, CSS and JavaScript source files.
- Added a local-only FastAPI server and health/config/print settings endpoints.
- Connected the extraction button to single-PDF text extraction with evidence/review output.
- Added synthetic-PDF API integration tests and GitHub Actions test workflow.
- Bundled the reviewed parser, format rules, JSON configurations and code-only reference registry.
- No Railway rate/deduction/admissibility logic added.
