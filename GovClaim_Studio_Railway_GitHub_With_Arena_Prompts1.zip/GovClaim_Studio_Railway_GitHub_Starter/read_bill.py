"""Local CLI for reading a hospital PDF into review-only JSON evidence."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from railway_bill_read_rules import parse_hospital_bill_pdf


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Extract reviewable hospital bill evidence. This does not calculate "
            "Railway payable rates, deductions, or claim admissibility."
        )
    )
    parser.add_argument("pdf", help="Path to a locally authorized hospital-bill PDF")
    parser.add_argument(
        "--output",
        help="Where to write JSON; default prints to stdout (may contain patient data)",
    )
    parser.add_argument("--registry", help="Optional path to cghs_code_registry.json")
    args = parser.parse_args()

    try:
        result = parse_hospital_bill_pdf(args.pdf, args.registry or
            Path(__file__).resolve().parent / "data" / "cghs_code_registry.json")
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    output = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        out_path = Path(args.output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(output + "\n", encoding="utf-8")
        print(f"Wrote review-only extraction JSON to: {out_path}")
        print("Protect this file: it may contain patient identifiers and bill line items.")
    else:
        print(output)
        print(
            "\nWARNING: stdout may contain patient data. Use an authorized local "
            "environment and secure the output.",
            file=sys.stderr,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
