# Source Map and Extraction Boundaries

## Input A: `UPDATE-CGHS-ENHANCMENT-BOT-01a10125(1).zip`

Only bill-reading/parser concepts are ported into `railway_bill_read_rules.py` and `config/bill_read_rules.json`.

Included concepts:
1. PyMuPDF `page.get_text("blocks")` / `page.get_text("text")` style extraction, Y-based visual row clustering and left-to-right block ordering.
2. Department-context tracking and row evidence carrying page, source row, section and service description.
3. Exact registry-based code resolution. No fuzzy matching and no wildcard/auto-generated code families.
4. Source-backed compound category composition and same-row context aliases; unresolved conditions stay review-required.
5. Oxygen duration interpretation (FULL DAY=24, HALF DAY=12, otherwise 1 with review warning) and conflicts flagged.
6. Detailed subtotal reading; section summary rows, payer/patient-payable regions, duplicate subtotal labels and equal-but-distinct subtotal positions handled conservatively.
7. Reading-only totals named as legacy aggregates (`DRUG100`, `CNSU100`) with explicit warning that they do not imply Railway admissibility.
8. Room Rent row counting and legacy derived quantities are returned as review candidates only.
9. Patient data allow-list and non-essential fields excluded by default.

Not included:
- Portal automation, login/session/captcha flows, network/client actions, claim submission or unrelated desktop integration.
- Any original patient/sample PDF or PII.
- Original rate amounts, price columns, package rates, calculation tables or official Railway deductions.

## Input B: `HFOS_v5.0_FULL_RELEASE.zip`

Only billing presentation and adjacent options are adapted into `bill_format_rules.py` and `config/bill_format_settings.json`.

Included concepts:
1. A4 page geometry (210 × 297 mm / 595.28 × 841.89 pt).
2. Standard, short-letterhead and plain-paper margin presets; standard defaults top=60 mm, bottom=20 mm, left=12 mm, right=12 mm.
3. Same top reserve on continuation pages, print CSS uses `@page` margins, monochrome output and page-break safety.
4. Bill identifiers/dates/patient details, code/particular/rate/quantity/currency/amount columns, table proportions, formal centered title, boxed/double-underlined total, optional Indian-numbering amount in words, credit/footer/signature and optional verification code area.
5. Validation concepts: margin geometry validation, amount reconciliation, duplicate detection preference, manual override reason, draft save/restore, PDF preview/export/print fallbacks, PDF history, rate lock outside admin and review flags kept in UI rather than printed claim output.
6. Legacy CGHS item-priority display option retained as a setting but OFF by default in the Railway profile.

Not included:
- Full HFOS application, JavaScript runtime, database/storage/auth/portal/automation code, bundled third-party code, source patient data or complete product implementation.
- Any HFOS rate amount as a Railway rate.

## Code reference registry

`data/cghs_code_registry.json` was built from `cghs/locators.py::_CGHS_MASTER_ROWS` in the supplied Enhancement Bot archive.

It contains only:
- serial number,
- code,
- description,
- speciality.

The original `nabh_rate` field is deliberately discarded. `record_count` is 1,998 and the registry is intended only as a code/description cross-reference from the supplied source snapshot. It is **not asserted to be current, official, or Railway-approved**. Check the `source_file_sha256` and source archive labels in the JSON file for provenance.

## Railway boundary

This package is a Railway-first *workflow target*, not a Railway rules catalogue. Until official, versioned Railway circulars and approved tariff data are loaded, all code descriptions are matching evidence only, all historic aggregates stay reviewable, and no payable rate/deduction is calculated here.
