# GitHub Upload Guide (Hinglish)

Yeh ZIP GitHub repository mein source files upload karne ke liye hai. **ZIP file ko GitHub repo par direct upload mat karna** agar tum chahte ho ki code files folder structure ke saath repository mein dikhein. Pehle ZIP extract karo.

## Recommended: Windows PowerShell se push

1. ZIP par right-click → **Extract All**.
2. Extracted `GovClaim_Studio_Railway_GitHub_Starter` folder kholo.
3. Us folder ki address bar mein `powershell` type karke Enter dabao.
4. Apni GitHub website par ek nayi **private, empty repository** banao. README, license ya `.gitignore` GitHub par pehle se create na karo, kyunki starter mein ye files already hain.
5. PowerShell mein commands chalao. Repository URL apni private repository URL se replace karna:

```powershell
git init
git add .
git status
```

`git status` mein verify karo ki source files, tests, docs, config aur frontend files aa rahi hain. Koi real patient bill, extracted real patient JSON, token, password ya `.env` file stage nahi honi chahiye. Phir:

```powershell
git commit -m "Initial Railway-first GovClaim Studio codebase"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

`YOUR_USERNAME` aur `YOUR_REPOSITORY` ko apni details se replace karna.

## Agar Git installed nahi hai

Pehle Git install karo ya GitHub Desktop use karo. ZIP ko dobara ZIP karke upload mat karna; repository mein extracted files aur folders chahiye, na ki source bundle ki ZIP.

## Included files

- `frontend/` — HTML, CSS, JavaScript UI source
- `backend/` — FastAPI local development API
- `railway_bill_read_rules.py`, `bill_format_rules.py`, `read_bill.py` — Python reader/print rules
- `config/`, `data/` — JSON rules and code-description reference snapshot
- `tests/` — synthetic-data tests
- `.github/workflows/` — automated test workflow
- `requirements.txt`, README files, `ARENA_PROMPT.md` — setup and development handoff

## Important

- Repository abhi **Railway-first starter** hai, production claim-processing system nahi.
- CGHS code registry ko current/approved Railway tariff mat samajhna.
- Real hospital PDFs/JSON, patient identifiers, local databases, `.env`, `.venv` aur generated outputs commit mat karna. `.gitignore` ismein help karta hai, lekin commit se pehle `git status` verify karna zaroori hai.
