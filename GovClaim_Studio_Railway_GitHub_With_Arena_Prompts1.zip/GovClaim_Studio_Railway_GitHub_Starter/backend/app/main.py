"""Local-only FastAPI app for GovClaim Studio Railway starter.

This is a development API, not a hardened multi-user deployment. Bind to loopback;
configure authentication, authorization, CSRF/rate limits and data-retention controls
before exposing it to any network.
"""
from __future__ import annotations

import json
import os
import re
import tempfile
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from bill_format_rules import PRINT_PRESETS_MM, margin_preset, validate_margins
from railway_bill_read_rules import explain_rule_scope, parse_hospital_bill_pdf

ROOT = Path(__file__).resolve().parents[2]
FRONTEND_DIR = ROOT / "frontend"
MAX_UPLOAD_BYTES = int(os.getenv("GOVCLAIM_MAX_UPLOAD_BYTES", str(25 * 1024 * 1024)))
APP_VERSION = "0.1.0"

app = FastAPI(
    title="GovClaim Studio — Railway-first starter API",
    version=APP_VERSION,
    description=(
        "Local development API for evidence-preserving PDF extraction and print settings. "
        "It does not implement Railway tariffs, admissibility or deduction policy."
    ),
    docs_url="/api/docs",
    redoc_url=None,
)
app.mount("/assets", StaticFiles(directory=FRONTEND_DIR / "assets"), name="assets")


class MarginRequest(BaseModel):
    margins_mm: dict[str, Any]


@app.middleware("http")
async def no_store_sensitive_api_responses(request, call_next):
    response = await call_next(request)
    if request.url.path.startswith("/api/claims"):
        response.headers["Cache-Control"] = "no-store, private"
        response.headers["Pragma"] = "no-cache"
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    return response


@app.get("/", include_in_schema=False)
async def index() -> FileResponse:
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/api/health")
async def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "app": "GovClaim Studio",
        "version": APP_VERSION,
        "scope": "railway-first-local-starter",
        "pdf_text_extraction": True,
        "official_rates_connected": False,
        "railway_policy_engine_connected": False,
        "persistent_claim_storage": False,
    }


@app.get("/api/config")
async def get_config() -> dict[str, Any]:
    read_rules = json.loads((ROOT / "config" / "bill_read_rules.json").read_text(encoding="utf-8"))
    format_rules = json.loads((ROOT / "config" / "bill_format_settings.json").read_text(encoding="utf-8"))
    return {
        "version": APP_VERSION,
        "workflow": "Indian Railways — Phase 1",
        "scope": explain_rule_scope(),
        "read_rules_version": read_rules.get("schema_version"),
        "format_rules_version": format_rules.get("schema_version"),
        "supported_uploads": ["application/pdf"],
        "max_upload_bytes": MAX_UPLOAD_BYTES,
        "production_ready": False,
    }


@app.get("/api/print/margins")
async def get_margin_presets() -> dict[str, Any]:
    presets = {key: margin_preset(key) for key in PRINT_PRESETS_MM}
    return {"presets": presets, "default_validation": validate_margins()}


@app.post("/api/print/margins/validate")
async def validate_print_margins(request: MarginRequest) -> dict[str, Any]:
    return validate_margins(request.margins_mm)


@app.post("/api/claims/parse")
async def parse_claim_pdf(file: UploadFile = File(...)) -> dict[str, Any]:
    """Parse one PDF in a temporary file, then delete it before returning review JSON."""
    name = Path(file.filename or "hospital_bill.pdf").name
    safe_name = re.sub(r"[^A-Za-z0-9._ -]", "_", name)[:120] or "hospital_bill.pdf"
    if not safe_name.lower().endswith(".pdf"):
        raise HTTPException(status_code=415, detail="Phase 1 API accepts PDF files only.")
    data = await file.read(MAX_UPLOAD_BYTES + 1)
    await file.close()
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail=f"File exceeds the {MAX_UPLOAD_BYTES // (1024*1024)} MB upload limit.")
    if not data.startswith(b"%PDF-"):
        raise HTTPException(status_code=415, detail="Uploaded file does not have a valid PDF signature.")

    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(prefix="govclaim_", suffix=".pdf", delete=False) as tmp:
            tmp.write(data)
            temp_path = Path(tmp.name)
        try:
            result = parse_hospital_bill_pdf(temp_path, ROOT / "data" / "cghs_code_registry.json")
        except Exception as exc:
            # Don't return local paths or raw tracebacks to the UI.
            message = str(exc).strip() or "PDF could not be parsed."
            raise HTTPException(status_code=422, detail=f"PDF extraction failed: {message[:240]}") from None
        result["source_file_name"] = safe_name
        result["api_notice"] = (
            "Review-only extraction. No official Railway rate, admissibility, package inclusion, "
            "deduction or payable total was calculated. Verify all extracted fields against the source."
        )
        return result
    finally:
        if temp_path is not None:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.app.main:app", host="127.0.0.1", port=8000, reload=False)
